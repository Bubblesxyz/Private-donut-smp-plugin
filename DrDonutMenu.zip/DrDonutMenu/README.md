# DrDonutMenu

A Paper 1.21.1 plugin recreating the Dr. Donut style main menu (Homes, Auction,
Friends, Orders, Sell, Pay, Teleport, Stats, Leaderboards, Settings).

**Fully working now:** Main Menu GUI, Homes, Teleport/RTP, Settings (persistent).
**Placeholders (click shows "coming soon"):** Auction, Friends, Orders, Sell, Pay, Stats, Leaderboards.

## Why you got source code instead of a .jar

I built and proofread this in a sandboxed environment with no internet access,
so I couldn't download the Paper API or Maven to compile it into a `.jar` for you.
Building it takes one command on any machine with internet — see below.

## How to build the .jar

1. Install a JDK 21 and Maven if you don't have them:
   - https://adoptium.net/ (JDK 21)
   - https://maven.apache.org/install.html
2. Open a terminal in this folder (the one with `pom.xml`).
3. Run:
   ```
   mvn clean package
   ```
4. The compiled plugin will be at `target/DrDonutMenu.jar`.
5. Drop that `.jar` into your server's `plugins/` folder and restart the server.

This project targets **Paper 1.21.11** specifically (`paper-api` version `1.21.11-R0.1-SNAPSHOT`
in `pom.xml`, and the resource pack's `pack_format: 75`, which is 1.21.11's format number —
different Minecraft patch versions bump this number, so if you ever move to a different
server version, both of these need to match it).

If you don't want to install Maven locally, you can also open this folder in
IntelliJ IDEA (it will detect the `pom.xml` automatically) and build it from there,
or push it to a GitHub repo and let a simple GitHub Actions workflow run `mvn package`
for you.

## Commands

- `/menu` — opens the main menu
- `/home [name]` — teleport to a home, or open the homes GUI with no name
- `/sethome <name>` — set a home at your location
- `/delhome <name>` — delete a home
- `/homes` — open the homes GUI
- `/rtp` — random teleport (cooldown + delay configurable in config.yml)
- `/settings` — open your personal settings GUI (PvP, particle trail, join messages, sound effects)

## Config

See `src/main/resources/config.yml` for home limits, RTP radius/cooldown/delay,
and default toggle values. Permissions for home limits are in `plugin.yml`
(`drdonutmenu.homes.3/5/10/unlimited`).

## The custom flat-button GUI (matches the reference photo)

The **Main Menu** (`/menu`) now recreates the flat gray button look pixel-for-pixel
using a resource pack, not item icons:

- `DrDonutResourcePack.zip` (shipped alongside this project) contains a custom font
  (`assets/drdonut/font/menu.json`) whose single character is the entire 10-button
  panel image (`assets/drdonut/textures/font/panel.png`), plus a fully transparent
  override of the chest GUI background (`assets/minecraft/textures/gui/container/generic_54.png`)
  so only your custom image and the sky show — no vanilla chest texture.
- `MainMenu.java` opens a plain 54-slot inventory with every slot left empty, and
  sets the inventory **title** to that one custom-font character. The "buttons" you
  see are the drawn image, not real items.
- Clicks are matched purely by **slot position** — small 3-slot-wide invisible
  hitboxes sit under where each button is drawn (see the `HOMES`, `AUCTION`, etc.
  arrays at the top of `MainMenu.java`).

### Hosting the resource pack

Minecraft won't auto-load a local zip — it needs to fetch it from a URL:

1. Upload `DrDonutResourcePack.zip` somewhere with a direct download link
   (e.g. a GitHub repo's "raw" file link, or Dropbox with `?dl=1` at the end of the URL).
2. In `server.properties`, set:
   ```
   resource-pack=https://your-direct-link/DrDonutResourcePack.zip
   resource-pack-sha1=<sha1 of the zip>
   ```
   Get the SHA1 with `sha1sum DrDonutResourcePack.zip` (Linux/Mac) or `certutil -hashfile DrDonutResourcePack.zip SHA1` (Windows).
3. Restart the server. Players will be prompted to download it on join.

For quick testing before you host it anywhere, just drop the unzipped folder into
your own `.minecraft/resourcepacks/` folder and enable it in-game — that lets you
see the menu exactly as designed without any server config yet.

### Aligning the custom GUI (important, read before reporting it "looks off")

I generated the button image and picked reasonable numbers for how large it renders
(`ascent`/`height` in `menu.json`) and where the invisible click zones sit
(the slot arrays in `MainMenu.java`), but I can't launch an actual Minecraft client
from here to verify pixel-perfect placement. The very likely outcome the first time
you test this: the drawn buttons and the clickable areas will be close, but maybe
not perfectly on top of each other. To fix it:

- **Buttons drawn too big/small:** change `"height"` in `menu.json` (bigger number = bigger image). Keep `"ascent"` less than or equal to `"height"`.
- **Buttons drawn too high/low or left/right:** this is harder to nudge from the font side; easiest fix is telling me the direction/amount it's off by and I'll adjust the padding baked into `panel.png` and regenerate it.
- **Clicks not landing on the right button:** adjust the slot number arrays in `MainMenu.java` (each is a row of 3 slots in a 9-wide, 6-row grid, slot 0 = top-left).

This is normal for this technique — it's genuinely a "tweak, reload resource pack, check" loop even for people building it by hand in-game. Send me a screenshot after your first test and I can recalculate the exact numbers instead of guessing again.

## Extending the placeholder buttons

Each placeholder (Auction, Friends, Orders, Sell, Pay, Stats, Leaderboards) is a
single case in `GuiListener.handleMainMenu()` and a single icon in `MainMenu.java`.
Adding a real module means: a new GUI class in `gui/`, a manager class for its data,
and one new case in the listener pointing to `YourNewMenu.open(player, plugin)`.
