package com.drdonut.menu.commands;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.gui.HomesMenu;
import com.drdonut.menu.homes.Home;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class HomeCommands implements CommandExecutor {

    private final DrDonutMenu plugin;

    public HomeCommands(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage(Component.text("Only players can use this command.").color(NamedTextColor.RED));
            return true;
        }

        switch (label.toLowerCase()) {
            case "sethome" -> {
                if (args.length < 1) {
                    player.sendMessage(Component.text("Usage: /sethome <name>").color(NamedTextColor.RED));
                    return true;
                }
                boolean ok = plugin.getHomeManager().setHome(player, args[0]);
                if (ok) {
                    player.sendMessage(Component.text("Home '" + args[0] + "' set!").color(NamedTextColor.GREEN));
                } else {
                    player.sendMessage(Component.text("You've reached your home limit.").color(NamedTextColor.RED));
                }
                return true;
            }
            case "delhome" -> {
                if (args.length < 1) {
                    player.sendMessage(Component.text("Usage: /delhome <name>").color(NamedTextColor.RED));
                    return true;
                }
                boolean ok = plugin.getHomeManager().deleteHome(player.getUniqueId(), args[0]);
                if (ok) {
                    player.sendMessage(Component.text("Home '" + args[0] + "' deleted.").color(NamedTextColor.GREEN));
                } else {
                    player.sendMessage(Component.text("No home found with that name.").color(NamedTextColor.RED));
                }
                return true;
            }
            case "home" -> {
                if (args.length < 1) {
                    HomesMenu.open(player, plugin);
                    return true;
                }
                Home home = plugin.getHomeManager().getHome(player.getUniqueId(), args[0]);
                if (home == null) {
                    player.sendMessage(Component.text("No home found with that name.").color(NamedTextColor.RED));
                    return true;
                }
                player.teleport(home.getLocation());
                player.sendMessage(Component.text("Teleported to home '" + args[0] + "'.").color(NamedTextColor.GREEN));
                return true;
            }
            case "homes" -> {
                HomesMenu.open(player, plugin);
                return true;
            }
            default -> {
                return false;
            }
        }
    }
}
