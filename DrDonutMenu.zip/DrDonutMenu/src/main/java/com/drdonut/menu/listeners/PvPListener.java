package com.drdonut.menu.listeners;

import com.drdonut.menu.DrDonutMenu;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class PvPListener implements Listener {

    private final DrDonutMenu plugin;

    public PvPListener(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (!(event.getEntity() instanceof Player victim)) return;

        Player attacker = resolveAttacker(event);
        if (attacker == null) return;

        boolean victimAllows = plugin.getSettingsManager().get(victim.getUniqueId()).isPvpEnabled();
        boolean attackerAllows = plugin.getSettingsManager().get(attacker.getUniqueId()).isPvpEnabled();

        if (!victimAllows || !attackerAllows) {
            event.setCancelled(true);
            Player toNotify = !victimAllows ? attacker : victim;
            Player blocked = !victimAllows ? victim : attacker;
            toNotify.sendMessage(Component.text(blocked.getName() + " has PvP disabled.").color(NamedTextColor.RED));
        }
    }

    private Player resolveAttacker(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player p) return p;
        if (event.getDamager() instanceof org.bukkit.entity.Projectile proj
                && proj.getShooter() instanceof Player p) {
            return p;
        }
        return null;
    }
}
