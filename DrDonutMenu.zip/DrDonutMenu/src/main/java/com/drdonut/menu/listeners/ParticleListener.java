package com.drdonut.menu.listeners;

import com.drdonut.menu.DrDonutMenu;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerMoveEvent;

public class ParticleListener implements Listener {

    private final DrDonutMenu plugin;

    public ParticleListener(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onMove(PlayerMoveEvent event) {
        if (event.getTo() == null) return;
        // Only bother spawning a particle when the player actually changed block position.
        if (event.getFrom().getBlockX() == event.getTo().getBlockX()
                && event.getFrom().getBlockY() == event.getTo().getBlockY()
                && event.getFrom().getBlockZ() == event.getTo().getBlockZ()) {
            return;
        }

        boolean enabled = plugin.getSettingsManager().get(event.getPlayer().getUniqueId()).isParticleTrail();
        if (!enabled) return;

        Location loc = event.getFrom().clone().add(0, 0.1, 0);
        event.getPlayer().getWorld().spawnParticle(Particle.END_ROD, loc, 3, 0.1, 0.05, 0.1, 0.001);
    }
}
