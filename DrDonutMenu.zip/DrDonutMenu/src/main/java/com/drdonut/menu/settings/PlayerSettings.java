package com.drdonut.menu.settings;

public class PlayerSettings {

    private boolean pvpEnabled;
    private boolean particleTrail;
    private boolean joinMessages;
    private boolean soundEffects;

    public PlayerSettings(boolean pvpEnabled, boolean particleTrail, boolean joinMessages, boolean soundEffects) {
        this.pvpEnabled = pvpEnabled;
        this.particleTrail = particleTrail;
        this.joinMessages = joinMessages;
        this.soundEffects = soundEffects;
    }

    public boolean isPvpEnabled() {
        return pvpEnabled;
    }

    public void setPvpEnabled(boolean pvpEnabled) {
        this.pvpEnabled = pvpEnabled;
    }

    public boolean isParticleTrail() {
        return particleTrail;
    }

    public void setParticleTrail(boolean particleTrail) {
        this.particleTrail = particleTrail;
    }

    public boolean isJoinMessages() {
        return joinMessages;
    }

    public void setJoinMessages(boolean joinMessages) {
        this.joinMessages = joinMessages;
    }

    public boolean isSoundEffects() {
        return soundEffects;
    }

    public void setSoundEffects(boolean soundEffects) {
        this.soundEffects = soundEffects;
    }
}
