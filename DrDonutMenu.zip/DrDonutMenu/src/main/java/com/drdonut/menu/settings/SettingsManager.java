package com.drdonut.menu.settings;

import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

public class SettingsManager {

    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration config;
    private final Map<UUID, PlayerSettings> cache = new HashMap<>();

    public SettingsManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "settings.yml");
        if (!file.exists()) {
            plugin.getDataFolder().mkdirs();
            try {
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "Could not create settings.yml", e);
            }
        }
        this.config = YamlConfiguration.loadConfiguration(file);
    }

    public PlayerSettings get(UUID uuid) {
        return cache.computeIfAbsent(uuid, id -> {
            String base = "players." + id + ".";
            boolean pvp = config.getBoolean(base + "pvp", plugin.getConfig().getBoolean("settings.default-pvp-enabled", true));
            boolean trail = config.getBoolean(base + "particle-trail", plugin.getConfig().getBoolean("settings.default-particle-trail", false));
            boolean joinMsg = config.getBoolean(base + "join-messages", plugin.getConfig().getBoolean("settings.default-join-messages", true));
            boolean sound = config.getBoolean(base + "sound-effects", plugin.getConfig().getBoolean("settings.default-sound-effects", true));
            return new PlayerSettings(pvp, trail, joinMsg, sound);
        });
    }

    public void save(UUID uuid) {
        PlayerSettings settings = cache.get(uuid);
        if (settings == null) return;
        String base = "players." + uuid + ".";
        config.set(base + "pvp", settings.isPvpEnabled());
        config.set(base + "particle-trail", settings.isParticleTrail());
        config.set(base + "join-messages", settings.isJoinMessages());
        config.set(base + "sound-effects", settings.isSoundEffects());
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save settings.yml", e);
        }
    }

    public void unload(UUID uuid) {
        save(uuid);
        cache.remove(uuid);
    }
}
