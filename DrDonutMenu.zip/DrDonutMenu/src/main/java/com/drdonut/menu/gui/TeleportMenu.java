package com.drdonut.menu.gui;

import com.drdonut.menu.util.ItemBuilder;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public class TeleportMenu {

    public static void open(Player player) {
        MenuHolder holder = new MenuHolder(MenuHolder.MenuType.TELEPORT);
        Inventory inv = Bukkit.createInventory(holder, 27, Component.text("Teleport").color(NamedTextColor.GOLD));
        holder.setInventory(inv);

        inv.setItem(13, new ItemBuilder(Material.ENDER_PEARL)
                .name(Component.text("Random Teleport").color(NamedTextColor.YELLOW))
                .lore(Component.text("Teleport to a random safe location").color(NamedTextColor.GRAY))
                .build());

        inv.setItem(22, HomesMenu.backButton());

        player.openInventory(inv);
    }
}
