package com.drdonut.menu.gui;

import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

/**
 * Recreates the exact flat-button look from the reference screenshot using a
 * resource-pack technique: the whole 10-button panel is ONE custom-font glyph
 * drawn as the inventory title (see the DrDonutResourcePack: assets/drdonut/font/menu.json
 * + assets/drdonut/textures/font/panel.png), and the vanilla chest background
 * is overridden to fully transparent so only the sky + our custom image show.
 *
 * The inventory itself stays a normal 54-slot container - we just leave every
 * slot empty (no icons) and use invisible hitboxes (a few slots wide each) lined
 * up under where each button is drawn in the panel image, so a click anywhere
 * in that region triggers the right action. See GuiListener#handleMainMenu.
 *
 * IMPORTANT - first-time setup note: exact pixel alignment between the custom
 * title image and the slot grid depends on values (ascent/height in menu.json,
 * and the slot ranges below) that can only be fine-tuned by looking at it in an
 * actual client. If the hitboxes feel a row or two off from the drawn buttons,
 * see the README's "Aligning the custom GUI" section.
 */
public class MainMenu {

    private static final Key FONT_KEY = Key.key("drdonut", "menu");
    private static final String PANEL_CHAR = new String(Character.toChars(0xF0000));

    // Each button gets a 3-slot-wide horizontal hitbox. Adjust these if the
    // clickable area doesn't line up with the drawn button in-game.
    public static final int[] HOMES = {10, 11, 12};
    public static final int[] AUCTION = {14, 15, 16};
    public static final int[] FRIENDS = {19, 20, 21};
    public static final int[] ORDERS = {23, 24, 25};
    public static final int[] SELL = {28, 29, 30};
    public static final int[] PAY = {32, 33, 34};
    public static final int[] TELEPORT = {37, 38, 39};
    public static final int[] STATS = {41, 42, 43};
    public static final int[] LEADERBOARDS = {46, 47, 48};
    public static final int[] SETTINGS = {50, 51, 52};

    public static void open(Player player) {
        MenuHolder holder = new MenuHolder(MenuHolder.MenuType.MAIN);

        Component title = Component.text(PANEL_CHAR).font(FONT_KEY);
        Inventory inv = Bukkit.createInventory(holder, 54, title);
        holder.setInventory(inv);

        // Every slot stays empty on purpose - the visible "buttons" are drawn
        // entirely by the custom font title, not by items.

        player.openInventory(inv);
    }

    /**
     * Returns a short action name for a clicked slot in the main menu, or
     * null if the slot isn't one of the button hitboxes.
     */
    public static String actionForSlot(int slot) {
        if (contains(HOMES, slot)) return "Homes";
        if (contains(AUCTION, slot)) return "Auction";
        if (contains(FRIENDS, slot)) return "Friends";
        if (contains(ORDERS, slot)) return "Orders";
        if (contains(SELL, slot)) return "Sell";
        if (contains(PAY, slot)) return "Pay";
        if (contains(TELEPORT, slot)) return "Teleport";
        if (contains(STATS, slot)) return "Stats";
        if (contains(LEADERBOARDS, slot)) return "Leaderboards";
        if (contains(SETTINGS, slot)) return "Settings";
        return null;
    }

    private static boolean contains(int[] arr, int value) {
        for (int v : arr) if (v == value) return true;
        return false;
    }
}
