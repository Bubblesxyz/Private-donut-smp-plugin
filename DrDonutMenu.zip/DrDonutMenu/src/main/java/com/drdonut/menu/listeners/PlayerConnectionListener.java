package com.drdonut.menu.listeners;

import com.drdonut.menu.DrDonutMenu;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

public class PlayerConnectionListener implements Listener {

    private final DrDonutMenu plugin;

    public PlayerConnectionListener(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.getSettingsManager().unload(event.getPlayer().getUniqueId());
    }
}
