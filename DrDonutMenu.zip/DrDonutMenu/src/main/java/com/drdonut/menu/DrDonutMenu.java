package com.drdonut.menu;

import com.drdonut.menu.commands.HomeCommands;
import com.drdonut.menu.commands.MenuCommand;
import com.drdonut.menu.commands.RTPCommand;
import com.drdonut.menu.commands.SettingsCommand;
import com.drdonut.menu.homes.HomeManager;
import com.drdonut.menu.listeners.GuiListener;
import com.drdonut.menu.listeners.ParticleListener;
import com.drdonut.menu.listeners.PlayerConnectionListener;
import com.drdonut.menu.listeners.PvPListener;
import com.drdonut.menu.settings.SettingsManager;
import com.drdonut.menu.teleport.RTPManager;
import org.bukkit.plugin.java.JavaPlugin;

public class DrDonutMenu extends JavaPlugin {

    private HomeManager homeManager;
    private SettingsManager settingsManager;
    private RTPManager rtpManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        this.homeManager = new HomeManager(this);
        this.settingsManager = new SettingsManager(this);
        this.rtpManager = new RTPManager(this);

        registerCommands();
        registerListeners();

        getLogger().info("DrDonutMenu enabled.");
    }

    @Override
    public void onDisable() {
        if (homeManager != null) homeManager.save();
        getLogger().info("DrDonutMenu disabled.");
    }

    private void registerCommands() {
        getCommand("menu").setExecutor(new MenuCommand());
        getCommand("settings").setExecutor(new SettingsCommand(this));
        getCommand("rtp").setExecutor(new RTPCommand(this));

        HomeCommands homeCommands = new HomeCommands(this);
        getCommand("home").setExecutor(homeCommands);
        getCommand("sethome").setExecutor(homeCommands);
        getCommand("delhome").setExecutor(homeCommands);
        getCommand("homes").setExecutor(homeCommands);
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new GuiListener(this), this);
        getServer().getPluginManager().registerEvents(new PvPListener(this), this);
        getServer().getPluginManager().registerEvents(new ParticleListener(this), this);
        getServer().getPluginManager().registerEvents(new PlayerConnectionListener(this), this);
    }

    public HomeManager getHomeManager() {
        return homeManager;
    }

    public SettingsManager getSettingsManager() {
        return settingsManager;
    }

    public RTPManager getRtpManager() {
        return rtpManager;
    }
}
