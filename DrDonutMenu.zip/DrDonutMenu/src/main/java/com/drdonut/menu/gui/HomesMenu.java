package com.drdonut.menu.gui;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.homes.Home;
import com.drdonut.menu.util.ItemBuilder;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class HomesMenu {

    public static void open(Player player, DrDonutMenu plugin) {
        MenuHolder holder = new MenuHolder(MenuHolder.MenuType.HOMES);
        Inventory inv = Bukkit.createInventory(holder, 45, Component.text("Your Homes").color(NamedTextColor.GOLD));
        holder.setInventory(inv);

        Map<String, Home> homes = plugin.getHomeManager().getHomes(player.getUniqueId());
        int maxHomes = plugin.getHomeManager().getMaxHomes(player);

        int slot = 0;
        List<Home> homeList = new ArrayList<>(homes.values());
        for (Home home : homeList) {
            if (slot >= 36) break;
            inv.setItem(slot, new ItemBuilder(Material.RED_BED)
                    .name(Component.text(home.getName()).color(NamedTextColor.YELLOW))
                    .lore(
                            Component.text("Left click to teleport").color(NamedTextColor.GRAY),
                            Component.text("Shift-click to delete").color(NamedTextColor.RED)
                    )
                    .build());
            slot++;
        }

        // Create-home button
        String maxLabel = maxHomes == Integer.MAX_VALUE ? "unlimited" : String.valueOf(maxHomes);
        ItemStack createItem = new ItemBuilder(Material.EMERALD)
                .name(Component.text("Create Home").color(NamedTextColor.GREEN))
                .lore(
                        Component.text("You have " + homes.size() + "/" + maxLabel + " homes").color(NamedTextColor.GRAY),
                        Component.text("Use /sethome <name>").color(NamedTextColor.GRAY)
                )
                .build();
        inv.setItem(40, createItem);

        // Back button
        inv.setItem(36, backButton());

        player.openInventory(inv);
    }

    public static ItemStack backButton() {
        return new ItemBuilder(Material.ARROW)
                .name(Component.text("Back").color(NamedTextColor.RED))
                .build();
    }
}
