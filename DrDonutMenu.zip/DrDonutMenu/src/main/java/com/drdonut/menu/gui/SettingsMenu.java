package com.drdonut.menu.gui;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.settings.PlayerSettings;
import com.drdonut.menu.util.ItemBuilder;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;

public class SettingsMenu {

    public static void open(Player player, DrDonutMenu plugin) {
        MenuHolder holder = new MenuHolder(MenuHolder.MenuType.SETTINGS);
        Inventory inv = Bukkit.createInventory(holder, 27, Component.text("Settings").color(NamedTextColor.GOLD));
        holder.setInventory(inv);

        PlayerSettings settings = plugin.getSettingsManager().get(player.getUniqueId());

        inv.setItem(10, toggleItem("PvP", "pvp", settings.isPvpEnabled()));
        inv.setItem(12, toggleItem("Particle Trail", "particle-trail", settings.isParticleTrail()));
        inv.setItem(14, toggleItem("Join Messages", "join-messages", settings.isJoinMessages()));
        inv.setItem(16, toggleItem("Sound Effects", "sound-effects", settings.isSoundEffects()));

        inv.setItem(22, HomesMenu.backButton());

        player.openInventory(inv);
    }

    private static org.bukkit.inventory.ItemStack toggleItem(String label, String key, boolean value) {
        Material material = value ? Material.LIME_DYE : Material.GRAY_DYE;
        String state = value ? "ON" : "OFF";
        NamedTextColor color = value ? NamedTextColor.GREEN : NamedTextColor.RED;

        return new ItemBuilder(material)
                .name(Component.text(label).color(NamedTextColor.YELLOW))
                .lore(
                        Component.text("Currently: ").color(NamedTextColor.GRAY).append(Component.text(state).color(color)),
                        Component.text("Click to toggle").color(NamedTextColor.DARK_GRAY)
                )
                .build();
    }
}
