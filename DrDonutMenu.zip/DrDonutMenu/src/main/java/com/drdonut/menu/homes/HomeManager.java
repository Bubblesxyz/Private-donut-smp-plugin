package com.drdonut.menu.homes;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;

public class HomeManager {

    private final JavaPlugin plugin;
    private final File file;
    private final YamlConfiguration config;
    private final Map<UUID, Map<String, Home>> cache = new LinkedHashMap<>();

    public HomeManager(JavaPlugin plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "homes.yml");
        if (!file.exists()) {
            plugin.getDataFolder().mkdirs();
            try {
                file.createNewFile();
            } catch (IOException e) {
                plugin.getLogger().log(Level.SEVERE, "Could not create homes.yml", e);
            }
        }
        this.config = YamlConfiguration.loadConfiguration(file);
        loadAll();
    }

    private void loadAll() {
        if (config.getConfigurationSection("players") == null) return;
        for (String uuidStr : config.getConfigurationSection("players").getKeys(false)) {
            UUID uuid = UUID.fromString(uuidStr);
            Map<String, Home> homes = new LinkedHashMap<>();
            String path = "players." + uuidStr + ".homes";
            if (config.getConfigurationSection(path) != null) {
                for (String homeName : config.getConfigurationSection(path).getKeys(false)) {
                    String base = path + "." + homeName + ".";
                    World world = Bukkit.getWorld(config.getString(base + "world", "world"));
                    if (world == null) continue;
                    Location loc = new Location(
                            world,
                            config.getDouble(base + "x"),
                            config.getDouble(base + "y"),
                            config.getDouble(base + "z"),
                            (float) config.getDouble(base + "yaw"),
                            (float) config.getDouble(base + "pitch")
                    );
                    homes.put(homeName.toLowerCase(), new Home(homeName, loc));
                }
            }
            cache.put(uuid, homes);
        }
    }

    public void save() {
        try {
            config.save(file);
        } catch (IOException e) {
            plugin.getLogger().log(Level.SEVERE, "Could not save homes.yml", e);
        }
    }

    public Map<String, Home> getHomes(UUID uuid) {
        return cache.computeIfAbsent(uuid, k -> new LinkedHashMap<>());
    }

    public Home getHome(UUID uuid, String name) {
        return getHomes(uuid).get(name.toLowerCase());
    }

    public int getMaxHomes(Player player) {
        if (player.hasPermission("drdonutmenu.homes.unlimited")) return Integer.MAX_VALUE;
        if (player.hasPermission("drdonutmenu.homes.10")) return 10;
        if (player.hasPermission("drdonutmenu.homes.5")) return 5;
        if (player.hasPermission("drdonutmenu.homes.3")) return 3;
        return plugin.getConfig().getInt("homes.default-max", 3);
    }

    public boolean setHome(Player player, String name) {
        Map<String, Home> homes = getHomes(player.getUniqueId());
        boolean overwriting = homes.containsKey(name.toLowerCase());
        if (!overwriting && homes.size() >= getMaxHomes(player)) {
            return false;
        }
        Home home = new Home(name, player.getLocation().clone());
        homes.put(name.toLowerCase(), home);

        String base = "players." + player.getUniqueId() + ".homes." + name + ".";
        Location loc = home.getLocation();
        config.set(base + "world", loc.getWorld().getName());
        config.set(base + "x", loc.getX());
        config.set(base + "y", loc.getY());
        config.set(base + "z", loc.getZ());
        config.set(base + "yaw", (double) loc.getYaw());
        config.set(base + "pitch", (double) loc.getPitch());
        save();
        return true;
    }

    public boolean deleteHome(UUID uuid, String name) {
        Map<String, Home> homes = getHomes(uuid);
        Home existing = homes.get(name.toLowerCase());
        if (existing == null) return false;
        homes.remove(name.toLowerCase());
        // use the originally-stored casing so the yaml key actually matches
        config.set("players." + uuid + ".homes." + existing.getName(), null);
        save();
        return true;
    }
}
