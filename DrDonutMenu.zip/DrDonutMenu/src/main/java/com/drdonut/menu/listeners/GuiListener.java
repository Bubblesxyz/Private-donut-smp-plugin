package com.drdonut.menu.listeners;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.gui.HomesMenu;
import com.drdonut.menu.gui.MainMenu;
import com.drdonut.menu.gui.MenuHolder;
import com.drdonut.menu.gui.SettingsMenu;
import com.drdonut.menu.gui.TeleportMenu;
import com.drdonut.menu.homes.Home;
import com.drdonut.menu.settings.PlayerSettings;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class GuiListener implements Listener {

    private final DrDonutMenu plugin;

    public GuiListener(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        InventoryHolder rawHolder = event.getInventory().getHolder();
        if (!(rawHolder instanceof MenuHolder holder)) return;

        // Cancel all interaction with our menus - they're click-only, not storage.
        event.setCancelled(true);

        if (!(event.getWhoClicked() instanceof Player player)) return;

        // The main menu's "buttons" are drawn by a custom-font title image with
        // no real items in the slots, so it's routed purely by slot index.
        if (holder.getType() == MenuHolder.MenuType.MAIN) {
            String action = MainMenu.actionForSlot(event.getSlot());
            if (action != null) handleMainMenu(player, action);
            return;
        }

        ItemStack clicked = event.getCurrentItem();
        if (clicked == null || clicked.getType().isAir()) return;
        String name = plainName(clicked);

        switch (holder.getType()) {
            case HOMES -> handleHomesMenu(player, name, event.isShiftClick());
            case TELEPORT -> handleTeleportMenu(player, name);
            case SETTINGS -> handleSettingsMenu(player, event.getSlot());
            default -> {}
        }
    }

    private void handleMainMenu(Player player, String name) {
        switch (name) {
            case "Homes" -> HomesMenu.open(player, plugin);
            case "Teleport" -> TeleportMenu.open(player);
            case "Settings" -> SettingsMenu.open(player, plugin);
            case "Auction", "Friends", "Orders", "Sell", "Pay", "Stats", "Leaderboards" ->
                    player.sendMessage(Component.text("That feature isn't available yet.").color(NamedTextColor.GRAY));
            default -> {}
        }
    }

    private void handleHomesMenu(Player player, String name, boolean shiftClick) {
        if (name.equals("Back")) {
            MainMenu.open(player);
            return;
        }
        if (name.equals("Create Home")) {
            player.closeInventory();
            player.sendMessage(Component.text("Use /sethome <name> to create a home here.").color(NamedTextColor.YELLOW));
            return;
        }

        Home home = plugin.getHomeManager().getHome(player.getUniqueId(), name);
        if (home == null) return;

        if (shiftClick) {
            plugin.getHomeManager().deleteHome(player.getUniqueId(), name);
            player.sendMessage(Component.text("Deleted home '" + name + "'.").color(NamedTextColor.RED));
            HomesMenu.open(player, plugin);
            return;
        }

        player.closeInventory();
        player.teleport(home.getLocation());
        player.sendMessage(Component.text("Teleported to home '" + name + "'.").color(NamedTextColor.GREEN));
    }

    private void handleTeleportMenu(Player player, String name) {
        if (name.equals("Back")) {
            MainMenu.open(player);
            return;
        }
        if (name.equals("Random Teleport")) {
            player.closeInventory();
            plugin.getRtpManager().beginRandomTeleport(player);
        }
    }

    private void handleSettingsMenu(Player player, int slot) {
        PlayerSettings settings = plugin.getSettingsManager().get(player.getUniqueId());
        switch (slot) {
            case 10 -> settings.setPvpEnabled(!settings.isPvpEnabled());
            case 12 -> settings.setParticleTrail(!settings.isParticleTrail());
            case 14 -> settings.setJoinMessages(!settings.isJoinMessages());
            case 16 -> settings.setSoundEffects(!settings.isSoundEffects());
            case 22 -> {
                MainMenu.open(player);
                return;
            }
            default -> {
                return;
            }
        }
        plugin.getSettingsManager().save(player.getUniqueId());
        SettingsMenu.open(player, plugin);
    }

    private String plainName(ItemStack item) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null || meta.displayName() == null) return "";
        return PlainTextComponentSerializer.plainText().serialize(meta.displayName());
    }
}
