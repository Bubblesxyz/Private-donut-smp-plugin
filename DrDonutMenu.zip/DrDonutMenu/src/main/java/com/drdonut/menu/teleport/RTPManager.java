package com.drdonut.menu.teleport;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;

public class RTPManager {

    private final JavaPlugin plugin;
    private final Random random = new Random();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Set<UUID> pendingTeleports = new HashSet<>();
    private final Map<UUID, Location> pendingStartLocation = new HashMap<>();

    public RTPManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isPending(UUID uuid) {
        return pendingTeleports.contains(uuid);
    }

    public long getRemainingCooldownSeconds(Player player) {
        if (player.hasPermission("drdonutmenu.rtp.nocooldown")) return 0;
        Long last = cooldowns.get(player.getUniqueId());
        if (last == null) return 0;
        long cooldownMs = plugin.getConfig().getLong("rtp.cooldown-seconds", 60) * 1000L;
        long elapsed = System.currentTimeMillis() - last;
        long remaining = cooldownMs - elapsed;
        return remaining > 0 ? (remaining / 1000) + 1 : 0;
    }

    public void beginRandomTeleport(Player player) {
        if (isPending(player.getUniqueId())) {
            player.sendMessage(Component.text("You already have a teleport pending.").color(NamedTextColor.RED));
            return;
        }
        long remaining = getRemainingCooldownSeconds(player);
        if (remaining > 0) {
            player.sendMessage(Component.text("You must wait " + remaining + "s before using /rtp again.").color(NamedTextColor.RED));
            return;
        }

        player.sendMessage(Component.text("Searching for a safe location...").color(NamedTextColor.GOLD));
        Location safe = findSafeLocation(player.getWorld());
        if (safe == null) {
            player.sendMessage(Component.text("Could not find a safe location, please try again.").color(NamedTextColor.RED));
            return;
        }

        int delay = plugin.getConfig().getInt("rtp.teleport-delay-seconds", 3);
        pendingTeleports.add(player.getUniqueId());
        pendingStartLocation.put(player.getUniqueId(), player.getLocation().clone());

        player.sendMessage(Component.text("Teleporting in " + delay + " seconds. Don't move!").color(NamedTextColor.YELLOW));

        new BukkitRunnableCountdown(player, safe, delay).runTaskTimer(plugin, 0L, 20L);
    }

    private class BukkitRunnableCountdown extends org.bukkit.scheduler.BukkitRunnable {
        private final Player player;
        private final Location destination;
        private int secondsLeft;

        BukkitRunnableCountdown(Player player, Location destination, int seconds) {
            this.player = player;
            this.destination = destination;
            this.secondsLeft = seconds;
        }

        @Override
        public void run() {
            if (!player.isOnline()) {
                cleanup();
                cancel();
                return;
            }

            Location startLoc = pendingStartLocation.get(player.getUniqueId());
            if (startLoc != null && hasMoved(startLoc, player.getLocation())) {
                player.sendMessage(Component.text("Teleport cancelled - you moved.").color(NamedTextColor.RED));
                cleanup();
                cancel();
                return;
            }

            if (secondsLeft <= 0) {
                player.teleport(destination);
                player.sendMessage(Component.text("Teleported!").color(NamedTextColor.GREEN));
                cooldowns.put(player.getUniqueId(), System.currentTimeMillis());
                cleanup();
                cancel();
                return;
            }

            secondsLeft--;
        }

        private void cleanup() {
            pendingTeleports.remove(player.getUniqueId());
            pendingStartLocation.remove(player.getUniqueId());
        }
    }

    private boolean hasMoved(Location a, Location b) {
        return a.getBlockX() != b.getBlockX() || a.getBlockY() != b.getBlockY() || a.getBlockZ() != b.getBlockZ();
    }

    private Location findSafeLocation(World world) {
        int minRadius = plugin.getConfig().getInt("rtp.min-radius", 200);
        int maxRadius = plugin.getConfig().getInt("rtp.max-radius", 5000);
        int maxAttempts = plugin.getConfig().getInt("rtp.max-attempts", 20);

        for (int i = 0; i < maxAttempts; i++) {
            int x = randomBetween(minRadius, maxRadius) * (random.nextBoolean() ? 1 : -1);
            int z = randomBetween(minRadius, maxRadius) * (random.nextBoolean() ? 1 : -1);

            int y = world.getHighestBlockYAt(x, z);
            Location candidate = new Location(world, x + 0.5, y + 1, z + 0.5);

            if (isSafe(candidate)) {
                return candidate;
            }
        }
        return null;
    }

    private boolean isSafe(Location loc) {
        World world = loc.getWorld();
        var groundBlock = world.getBlockAt(loc.getBlockX(), loc.getBlockY() - 1, loc.getBlockZ());
        var feetBlock = world.getBlockAt(loc.getBlockX(), loc.getBlockY(), loc.getBlockZ());
        var headBlock = world.getBlockAt(loc.getBlockX(), loc.getBlockY() + 1, loc.getBlockZ());

        if (!groundBlock.getType().isSolid()) return false;
        if (groundBlock.isLiquid()) return false;
        if (feetBlock.getType().isSolid() || feetBlock.isLiquid()) return false;
        if (headBlock.getType().isSolid() || headBlock.isLiquid()) return false;

        return true;
    }

    private int randomBetween(int min, int max) {
        if (max <= min) return min;
        return min + random.nextInt(max - min);
    }
}
