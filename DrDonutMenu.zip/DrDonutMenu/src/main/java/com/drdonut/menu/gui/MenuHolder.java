package com.drdonut.menu.gui;

import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.jetbrains.annotations.NotNull;

/**
 * Every custom GUI inventory carries one of these as its holder.
 * We identify menus by type (not by title text), which is robust
 * against renames/translations and avoids fragile string matching.
 */
public class MenuHolder implements InventoryHolder {

    public enum MenuType {
        MAIN,
        HOMES,
        TELEPORT,
        SETTINGS,
        PLACEHOLDER
    }

    private final MenuType type;
    private Inventory inventory;
    private String extraData; // e.g. a home name attached to a delete-confirm icon

    public MenuHolder(MenuType type) {
        this.type = type;
    }

    public MenuType getType() {
        return type;
    }

    public String getExtraData() {
        return extraData;
    }

    public void setExtraData(String extraData) {
        this.extraData = extraData;
    }

    public void setInventory(Inventory inventory) {
        this.inventory = inventory;
    }

    @Override
    @NotNull
    public Inventory getInventory() {
        return inventory;
    }
}
