package com.donutrtp.commands;

import com.donutrtp.DonutRTP;
import com.donutrtp.gui.RtpMenu;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class RtpCommand implements CommandExecutor {

    private final DonutRTP plugin;

    public RtpCommand(DonutRTP plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (args.length == 0) {
            RtpMenu.open(plugin, player);
        } else {
            plugin.rtp().start(player, args[0].toLowerCase());
        }
        return true;
    }
}
