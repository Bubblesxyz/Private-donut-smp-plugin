package com.drdonut.menu;

import com.drdonut.menu.commands.*;
import com.drdonut.menu.friends.FriendManager;
import com.drdonut.menu.gui.GuiListener;
import com.drdonut.menu.gui.MainMenuDialog;
import com.drdonut.menu.economy.VaultHook;
import com.drdonut.menu.homes.HomeManager;
import com.drdonut.menu.listeners.ScoreboardService;
import com.drdonut.menu.listeners.MessageListener;
import com.drdonut.menu.listeners.PlayerListener;
import com.drdonut.menu.listeners.SpawnListener;
import com.drdonut.menu.messages.MessageService;
import com.drdonut.menu.settings.Setting;
import com.drdonut.menu.settings.SettingsManager;
import com.drdonut.menu.teleport.RtpManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.Location;
import org.bukkit.Sound;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.PluginManager;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public final class DrDonutMenu extends JavaPlugin {

    private SettingsManager settings;
    private HomeManager homes;
    private FriendManager friends;
    private MessageService messages;
    private RtpManager rtp;
    private MainMenuDialog mainMenu;
    private ScoreboardService scoreboards;
    private Component prefix;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        prefix = LegacyComponentSerializer.legacyAmpersand()
                .deserialize(getConfig().getString("messages.prefix", "&6&lDr.Donut &8» &r"));

        settings = new SettingsManager(this);
        homes = new HomeManager(this);
        friends = new FriendManager(this);
        messages = new MessageService(settings, friends);
        rtp = new RtpManager(this);
        mainMenu = new MainMenuDialog(this);
        scoreboards = new ScoreboardService(this);

        PluginManager pm = getServer().getPluginManager();
        pm.registerEvents(new GuiListener(), this);
        pm.registerEvents(new PlayerListener(this), this);
        pm.registerEvents(new SpawnListener(this), this);
        pm.registerEvents(new MessageListener(this), this);

        MenuCommands menu = new MenuCommands(this);
        register("menu", menu);
        register("settings", menu);

        HomeCommands hc = new HomeCommands(this);
        for (String c : new String[]{"home", "sethome", "delhome", "homes"}) register(c, hc);

        register("rtp", new RtpCommand(this));

        FriendCommands fc = new FriendCommands(this);
        for (String c : new String[]{"friend", "follow", "unfollow"}) register(c, fc);

        TpaCommands tc = new TpaCommands(this);
        for (String c : new String[]{"tpa", "tpaccept", "tpdeny"}) register(c, tc);

        register("pay", new PayCommand(this));
        register("msg", new com.drdonut.menu.commands.MsgCommand(this));
    }

    @Override
    public void onDisable() {
        if (settings != null) settings.save();
        if (homes != null) homes.save();
        if (friends != null) friends.save();
    }

    private void register(String name, CommandExecutor executor) {
        PluginCommand cmd = getCommand(name);
        if (cmd != null) cmd.setExecutor(executor);
    }

    // ---- accessors ----
    public SettingsManager settings() { return settings; }
    public HomeManager homes() { return homes; }
    public FriendManager friends() { return friends; }
    public MessageService messages() { return messages; }
    public RtpManager rtp() { return rtp; }
    public MainMenuDialog mainMenu() { return mainMenu; }
    public ScoreboardService scoreboards() { return scoreboards; }

    /** Called right after a settings toggle is saved, for settings with an immediate side effect. */
    public void onSettingChanged(Player p, Setting s) {
        if (s == Setting.SCOREBOARD_VISIBLE) scoreboards.refresh(p);
        if (s == Setting.NIGHT_VISION) syncNightVision(p, true);
        if (s == Setting.PLAYER_VISIBILITY) applyPlayerVisibility(p);
    }

    /** When off, this player doesn't see others; when on, they see everyone currently online. */
    public void applyPlayerVisibility(Player p) {
        boolean show = settings.get(p.getUniqueId(), Setting.PLAYER_VISIBILITY);
        for (Player other : getServer().getOnlinePlayers()) {
            if (other.equals(p)) continue;
            if (show) p.showPlayer(this, other); else p.hidePlayer(this, other);
        }
    }


    // ---- message helpers ----
    public void send(CommandSender to, Component c) { to.sendMessage(prefix.append(c)); }
    public void info(CommandSender to, String text) { send(to, Component.text(text, NamedTextColor.YELLOW)); }
    public void ok(CommandSender to, String text) { send(to, Component.text(text, NamedTextColor.GREEN)); }
    public void error(CommandSender to, String text) { send(to, Component.text(text, NamedTextColor.RED)); }

    // ---- sounds ----
    public void click(Player p) {
        if (settings.get(p.getUniqueId(), Setting.SOUND_EFFECTS)) {
            p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.6f, 1.0f);
        }
    }

    public void whoosh(Player p) {
        if (settings.get(p.getUniqueId(), Setting.SOUND_EFFECTS)) {
            p.playSound(p.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 0.6f, 1.0f);
        }
    }

    // ---- night vision ----
    /** Gives infinite night vision if the player's setting is on; removes it if off and removeIfOff is true. */
    public void syncNightVision(Player p, boolean removeIfOff) {
        if (settings.get(p.getUniqueId(), Setting.NIGHT_VISION)) {
            p.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, PotionEffect.INFINITE_DURATION,
                    0, false, false, false));
        } else if (removeIfOff) {
            p.removePotionEffect(PotionEffectType.NIGHT_VISION);
        }
    }

    // ---- shared actions ----
    public boolean teleportHome(Player p, String name) {
        HomeManager.Home h = homes.get(p.getUniqueId(), name);
        if (h == null) {
            error(p, "No home found with that name.");
            return false;
        }
        Location loc = h.toLocation();
        if (loc == null) {
            error(p, "That home's world isn't loaded.");
            return false;
        }
        boolean quiet = settings.get(p.getUniqueId(), Setting.QUIET_SPAWN);
        p.teleportAsync(loc);
        if (!quiet) {
            ok(p, "Teleported to home '" + name + "'.");
            whoosh(p);
        }
        return true;
    }
}
