package com.drdonut.menu.commands;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.friends.FriendManager;
import com.drdonut.menu.gui.FriendsMenu;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public final class FriendCommands implements CommandExecutor {

    private final DrDonutMenu plugin;

    public FriendCommands(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    private OfflinePlayer find(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online;
        return Bukkit.getOfflinePlayerIfCached(name);
    }

    private String nameOf(OfflinePlayer p) {
        return p.getName() != null ? p.getName() : p.getUniqueId().toString();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player me)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        FriendManager fm = plugin.friends();
        UUID id = me.getUniqueId();
        String name = cmd.getName().toLowerCase();

        if (name.equals("follow") || name.equals("unfollow")) {
            if (args.length < 1) {
                plugin.error(me, "Usage: /" + name + " <player>");
                return true;
            }
            OfflinePlayer target = find(args[0]);
            if (target == null) {
                plugin.error(me, "Player not found.");
                return true;
            }
            if (target.getUniqueId().equals(id)) {
                plugin.error(me, "You can't do that to yourself.");
                return true;
            }
            if (name.equals("follow")) {
                if (fm.isFollowing(id, target.getUniqueId())) {
                    plugin.info(me, "You already follow " + nameOf(target) + ".");
                    return true;
                }
                fm.follow(id, target.getUniqueId());
                plugin.ok(me, "You now follow " + nameOf(target) + ". You'll always see their chat, joins and payments.");
                if (target instanceof Player tp) plugin.info(tp, me.getName() + " is now following you.");
            } else {
                fm.unfollow(id, target.getUniqueId());
                plugin.ok(me, "You no longer follow " + nameOf(target) + ".");
            }
            return true;
        }

        // /friend ...
        if (args.length == 0) {
            FriendsMenu.open(plugin, me);
            return true;
        }
        String sub = args[0].toLowerCase();
        if (sub.equals("list")) {
            StringBuilder sb = new StringBuilder();
            for (UUID f : fm.friendsOf(id)) {
                if (sb.length() > 0) sb.append(", ");
                sb.append(nameOf(Bukkit.getOfflinePlayer(f)));
            }
            plugin.info(me, sb.length() == 0 ? "You have no friends yet." : "Friends: " + sb);
            return true;
        }
        if (args.length < 2) {
            plugin.error(me, "Usage: /friend <add|accept|deny|remove|list> <player>");
            return true;
        }
        OfflinePlayer target = find(args[1]);
        if (target == null) {
            plugin.error(me, "Player not found.");
            return true;
        }
        UUID tid = target.getUniqueId();
        if (tid.equals(id)) {
            plugin.error(me, "You can't add yourself.");
            return true;
        }

        switch (sub) {
            case "add" -> {
                if (fm.areFriends(id, tid)) {
                    plugin.info(me, "You are already friends with " + nameOf(target) + ".");
                } else if (fm.hasRequest(tid, id)) {
                    fm.addFriends(id, tid);
                    plugin.ok(me, "You are now friends with " + nameOf(target) + "!");
                    if (target instanceof Player tp) plugin.ok(tp, me.getName() + " accepted your friend request!");
                } else if (!(target instanceof Player tp)) {
                    plugin.error(me, "That player must be online to receive a request.");
                } else {
                    fm.addRequest(id, tid);
                    plugin.ok(me, "Friend request sent to " + tp.getName() + ".");
                    plugin.send(tp, Component.text(me.getName() + " sent you a friend request. ", NamedTextColor.YELLOW)
                            .append(Component.text("[Accept]", NamedTextColor.GREEN)
                                    .clickEvent(ClickEvent.runCommand("/friend accept " + me.getName())))
                            .append(Component.text(" "))
                            .append(Component.text("[Deny]", NamedTextColor.RED)
                                    .clickEvent(ClickEvent.runCommand("/friend deny " + me.getName()))));
                }
            }
            case "accept" -> {
                if (!fm.hasRequest(tid, id)) {
                    plugin.error(me, "No friend request from " + nameOf(target) + ".");
                } else {
                    fm.addFriends(id, tid);
                    plugin.ok(me, "You are now friends with " + nameOf(target) + "!");
                    if (target instanceof Player tp) plugin.ok(tp, me.getName() + " accepted your friend request!");
                }
            }
            case "deny" -> {
                fm.removeRequest(tid, id);
                plugin.info(me, "Request from " + nameOf(target) + " denied.");
            }
            case "remove" -> {
                fm.removeFriends(id, tid);
                plugin.info(me, nameOf(target) + " is no longer your friend.");
            }
            default -> plugin.error(me, "Usage: /friend <add|accept|deny|remove|list> <player>");
        }
        return true;
    }
}
