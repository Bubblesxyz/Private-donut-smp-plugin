package com.drdonut.menu.gui;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.homes.HomeManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class HomesMenu {

    private HomesMenu() {}

    public static void open(DrDonutMenu plugin, Player player) {
        UUID id = player.getUniqueId();
        Map<String, HomeManager.Home> homes = plugin.homes().all(id);
        Gui.Holder holder = new Gui.Holder(54, Component.text("Homes"));

        int slot = 0;
        for (Map.Entry<String, HomeManager.Home> entry : homes.entrySet()) {
            if (slot >= 45) break;
            String name = entry.getKey();
            HomeManager.Home home = entry.getValue();
            holder.set(slot++, Gui.item(Material.RED_BED, Gui.text(name, NamedTextColor.GOLD), List.of(
                    Gui.text(home.world() + " " + (int) home.x() + ", " + (int) home.y() + ", " + (int) home.z(),
                            NamedTextColor.GRAY),
                    Gui.text("Left-click: teleport", NamedTextColor.GREEN),
                    Gui.text("Right-click: delete", NamedTextColor.RED)), false), e -> {
                if (e.getClick().isRightClick()) {
                    plugin.homes().delete(id, name);
                    plugin.click(player);
                    open(plugin, player);
                } else {
                    player.closeInventory();
                    plugin.teleportHome(player, name);
                }
            });
        }

        int limit = plugin.homes().limit(player);
        String limitText = limit == Integer.MAX_VALUE ? "unlimited" : String.valueOf(limit);
        holder.set(45, Gui.item(Material.OAK_SIGN, Gui.text("Homes: " + homes.size() + "/" + limitText, NamedTextColor.YELLOW),
                List.of(Gui.text("Set one with /sethome <name>", NamedTextColor.GRAY)), false), null);
        holder.set(49, Gui.item(Material.ARROW, Gui.text("Back", NamedTextColor.YELLOW), null, false), e -> {
            plugin.click(player);
            plugin.mainMenu().open(player);
        });
        holder.open(player);
    }
}
