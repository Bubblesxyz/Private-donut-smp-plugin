package com.drdonut.menu.gui;

import com.drdonut.menu.DrDonutMenu;
import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.body.DialogBody;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;

import java.util.List;

/** Friends screen matching the reference: title, a hint line, Add Friend / View / Back. */
public final class FriendsMenu {

    private FriendsMenu() {}

    public static void open(DrDonutMenu plugin, Player player) {
        List<ActionButton> buttons = List.of(
                ActionButton.create(Component.text("Add Friend"), null, 260,
                        // Pre-fills the chat bar with "/friend add " so the player just types a name and hits enter.
                        DialogAction.staticAction(ClickEvent.suggestCommand("/friend add "))),
                ActionButton.create(Component.text("View Friends"), null, 260,
                        DialogAction.staticAction(ClickEvent.runCommand("/friend list"))),
                ActionButton.create(Component.text("Back"), null, 260,
                        DialogAction.staticAction(ClickEvent.runCommand("/menu")))
        );

        Dialog dialog = Dialog.create(builder -> builder.empty()
                .base(DialogBase.builder(Component.text("Friends"))
                        .canCloseWithEscape(true)
                        .body(List.of(DialogBody.plainMessage(
                                Component.text("Friend chat: ", NamedTextColor.GRAY)
                                        .append(Component.text("/fc <message>", NamedTextColor.YELLOW)))))
                        .build())
                .type(DialogType.multiAction(buttons, null, 1)));
        player.showDialog(dialog);
    }
}
