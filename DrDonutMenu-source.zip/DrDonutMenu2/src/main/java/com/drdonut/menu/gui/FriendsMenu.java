package com.drdonut.menu.gui;

import com.drdonut.menu.DrDonutMenu;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;

import java.util.List;
import java.util.UUID;

public final class FriendsMenu {

    private FriendsMenu() {}

    private static String nameOf(OfflinePlayer p) {
        return p.getName() != null ? p.getName() : p.getUniqueId().toString().substring(0, 8);
    }

    private static ItemStack head(UUID uuid, NamedTextColor color, List<Component> lore) {
        OfflinePlayer off = Bukkit.getOfflinePlayer(uuid);
        ItemStack stack = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) stack.getItemMeta();
        meta.setOwningPlayer(off);
        meta.displayName(Gui.text(nameOf(off), color));
        meta.lore(lore);
        stack.setItemMeta(meta);
        return stack;
    }

    public static void open(DrDonutMenu plugin, Player player) {
        UUID me = player.getUniqueId();
        Gui.Holder holder = new Gui.Holder(54, Component.text("Friends & Following"));

        // Friends: slots 0-17
        int slot = 0;
        for (UUID friend : plugin.friends().friendsOf(me)) {
            if (slot >= 18) break;
            holder.set(slot++, head(friend, NamedTextColor.GREEN,
                    List.of(Gui.text("Friend", NamedTextColor.GRAY), Gui.text("Click to remove", NamedTextColor.RED))), e -> {
                plugin.friends().removeFriends(me, friend);
                plugin.click(player);
                open(plugin, player);
            });
        }

        // Friend requests: slots 18-26
        slot = 18;
        for (UUID from : plugin.friends().requestsFor(me)) {
            if (slot >= 27) break;
            holder.set(slot++, head(from, NamedTextColor.YELLOW,
                    List.of(Gui.text("Friend request", NamedTextColor.GRAY),
                            Gui.text("Left-click: accept", NamedTextColor.GREEN),
                            Gui.text("Right-click: deny", NamedTextColor.RED))), e -> {
                if (e.getClick().isRightClick()) {
                    plugin.friends().removeRequest(from, me);
                } else {
                    plugin.friends().addFriends(me, from);
                }
                plugin.click(player);
                open(plugin, player);
            });
        }

        // Following: slots 27-44
        slot = 27;
        for (UUID target : plugin.friends().followingOf(me)) {
            if (slot >= 45) break;
            holder.set(slot++, head(target, NamedTextColor.AQUA,
                    List.of(Gui.text("Following", NamedTextColor.GRAY), Gui.text("Click to unfollow", NamedTextColor.RED))), e -> {
                plugin.friends().unfollow(me, target);
                plugin.click(player);
                open(plugin, player);
            });
        }

        holder.set(45, Gui.item(Material.BOOK, Gui.text("How it works", NamedTextColor.YELLOW), List.of(
                Gui.text("/friend add <player>", NamedTextColor.GRAY),
                Gui.text("/follow <player>", NamedTextColor.GRAY),
                Gui.text("Followers: " + plugin.friends().followerCount(me), NamedTextColor.AQUA),
                Gui.text("You always see chat, joins, and pays", NamedTextColor.DARK_GRAY),
                Gui.text("from friends and people you follow.", NamedTextColor.DARK_GRAY)), false), null);
        holder.set(49, Gui.item(Material.ARROW, Gui.text("Back", NamedTextColor.YELLOW), null, false), e -> {
            plugin.click(player);
            plugin.mainMenu().open(player);
        });
        holder.open(player);
    }
}
