package com.drdonut.menu.commands;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.economy.VaultHook;
import com.drdonut.menu.settings.Setting;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.Locale;

public final class PayCommand implements CommandExecutor {

    private final DrDonutMenu plugin;

    public PayCommand(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    static double parseAmount(String raw) {
        String s = raw.toLowerCase(Locale.ROOT).replace(",", "");
        double mult = 1;
        if (s.endsWith("k")) mult = 1_000;
        else if (s.endsWith("m")) mult = 1_000_000;
        else if (s.endsWith("b")) mult = 1_000_000_000;
        if (mult != 1) s = s.substring(0, s.length() - 1);
        return Double.parseDouble(s) * mult;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player me)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (args.length < 2) {
            plugin.error(me, "Usage: /pay <player> <amount>");
            return true;
        }
        VaultHook vault = VaultHook.create(plugin);
        if (vault == null) {
            plugin.error(me, "Payments are unavailable (no Vault economy found).");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            plugin.error(me, "Player not found.");
            return true;
        }
        if (target.equals(me)) {
            plugin.error(me, "You can't pay yourself.");
            return true;
        }
        double amount;
        try {
            amount = parseAmount(args[1]);
        } catch (NumberFormatException ex) {
            plugin.error(me, "Invalid amount.");
            return true;
        }
        if (Double.isNaN(amount) || Double.isInfinite(amount) || amount <= 0) {
            plugin.error(me, "Invalid amount.");
            return true;
        }
        if (!vault.has(me, amount)) {
            plugin.error(me, "You don't have enough money.");
            return true;
        }
        if (!vault.withdraw(me, amount)) {
            plugin.error(me, "Payment failed.");
            return true;
        }
        if (!vault.deposit(target, amount)) {
            vault.deposit(me, amount); // refund
            plugin.error(me, "Payment failed.");
            return true;
        }

        String shown = vault.format(amount);
        plugin.ok(me, "You paid " + target.getName() + " " + shown + ".");
        // Friends / followed players always get through, even if pay messages are off.
        if (plugin.messages().canSee(target, Setting.PAY_MESSAGES, me.getUniqueId())) {
            plugin.ok(target, me.getName() + " paid you " + shown + ".");
        }
        return true;
    }
}
