package com.drdonut.menu.messages;

import com.drdonut.menu.friends.FriendManager;
import com.drdonut.menu.settings.Setting;
import com.drdonut.menu.settings.SettingsManager;
import org.bukkit.entity.Player;

import java.util.UUID;

/** Decides whether a viewer should see a message category. */
public final class MessageService {

    private final SettingsManager settings;
    private final FriendManager friends;

    public MessageService(SettingsManager settings, FriendManager friends) {
        this.settings = settings;
        this.friends = friends;
    }

    /**
     * A viewer sees a category if they left it on, OR the message comes from
     * a friend / someone they follow (those always get through).
     */
    public boolean canSee(Player viewer, Setting category, UUID source) {
        if (settings.get(viewer.getUniqueId(), category)) return true;
        return source != null && friends.sees(viewer.getUniqueId(), source);
    }
}
