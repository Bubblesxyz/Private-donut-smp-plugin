package com.drdonut.menu.homes;

import com.drdonut.menu.DrDonutMenu;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class HomeManager {

    public record Home(String world, double x, double y, double z, float yaw, float pitch) {
        public Location toLocation() {
            World w = Bukkit.getWorld(world);
            return w == null ? null : new Location(w, x, y, z, yaw, pitch);
        }

        public static Home of(Location l) {
            return new Home(l.getWorld().getName(), l.getX(), l.getY(), l.getZ(), l.getYaw(), l.getPitch());
        }
    }

    private final DrDonutMenu plugin;
    private final File file;
    private final Map<UUID, Map<String, Home>> homes = new HashMap<>();

    public HomeManager(DrDonutMenu plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "homes.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection root = yml.getConfigurationSection("homes");
        if (root == null) return;
        for (String id : root.getKeys(false)) {
            ConfigurationSection player = root.getConfigurationSection(id);
            if (player == null) continue;
            UUID uuid;
            try {
                uuid = UUID.fromString(id);
            } catch (IllegalArgumentException ex) {
                continue;
            }
            Map<String, Home> map = new LinkedHashMap<>();
            for (String name : player.getKeys(false)) {
                ConfigurationSection h = player.getConfigurationSection(name);
                if (h == null) continue;
                map.put(name, new Home(h.getString("world", "world"), h.getDouble("x"), h.getDouble("y"),
                        h.getDouble("z"), (float) h.getDouble("yaw"), (float) h.getDouble("pitch")));
            }
            homes.put(uuid, map);
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, Map<String, Home>> e : homes.entrySet()) {
            for (Map.Entry<String, Home> h : e.getValue().entrySet()) {
                String p = "homes." + e.getKey() + "." + h.getKey();
                Home home = h.getValue();
                yml.set(p + ".world", home.world());
                yml.set(p + ".x", home.x());
                yml.set(p + ".y", home.y());
                yml.set(p + ".z", home.z());
                yml.set(p + ".yaw", home.yaw());
                yml.set(p + ".pitch", home.pitch());
            }
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save homes.yml: " + ex.getMessage());
        }
    }

    public Map<String, Home> all(UUID id) {
        return homes.getOrDefault(id, Collections.emptyMap());
    }

    public Home get(UUID id, String name) {
        return all(id).get(name.toLowerCase(Locale.ROOT));
    }

    public void set(UUID id, String name, Location loc) {
        homes.computeIfAbsent(id, k -> new LinkedHashMap<>()).put(name.toLowerCase(Locale.ROOT), Home.of(loc));
        save();
    }

    public boolean delete(UUID id, String name) {
        Map<String, Home> map = homes.get(id);
        if (map == null || map.remove(name.toLowerCase(Locale.ROOT)) == null) return false;
        save();
        return true;
    }

    /** Home slots: config default, raised by drdonutmenu.homes.N permissions. */
    public int limit(Player p) {
        if (p.hasPermission("drdonutmenu.homes.unlimited")) return Integer.MAX_VALUE;
        int max = plugin.getConfig().getInt("homes.default-max", 3);
        for (int n : new int[]{10, 5, 3}) {
            if (p.hasPermission("drdonutmenu.homes." + n)) max = Math.max(max, n);
        }
        return max;
    }
}
