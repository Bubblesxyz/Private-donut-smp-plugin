package com.drdonut.menu.settings;

import org.bukkit.Material;

public enum SettingCategory {
    CHAT("\u2709 Chat", Material.WRITABLE_BOOK),
    NOTIFICATIONS("\u2691 Notifications", Material.BELL),
    PVP("\u2694 PvP", Material.DIAMOND_SWORD),
    VISUALS("\u2600 Visuals", Material.GLOWSTONE_DUST),
    PRIVACY("\u25AA Privacy", Material.IRON_DOOR),
    SCOREBOARD("\u25AA Scoreboard", Material.OAK_SIGN);

    private final String display;
    private final Material icon;

    SettingCategory(String display, Material icon) {
        this.display = display;
        this.icon = icon;
    }

    public String display() { return display; }
    public Material icon() { return icon; }
}
