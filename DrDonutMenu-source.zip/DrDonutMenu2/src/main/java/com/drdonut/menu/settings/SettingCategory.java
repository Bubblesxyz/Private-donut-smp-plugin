package com.drdonut.menu.settings;

import org.bukkit.Material;

public enum SettingCategory {
    CHAT("Chat", Material.WRITABLE_BOOK),
    NOTIFICATIONS("Notifications", Material.BELL),
    PVP("PvP", Material.DIAMOND_SWORD),
    VISUALS("Visuals", Material.GLOWSTONE_DUST),
    PRIVACY("Privacy", Material.IRON_DOOR),
    SCOREBOARD("Scoreboard", Material.OAK_SIGN);

    private final String display;
    private final Material icon;

    SettingCategory(String display, Material icon) {
        this.display = display;
        this.icon = icon;
    }

    public String display() { return display; }
    public Material icon() { return icon; }
}
