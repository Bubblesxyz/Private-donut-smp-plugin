package com.drdonut.menu.listeners;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.settings.Setting;
import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.server.BroadcastMessageEvent;

import java.util.Locale;
import java.util.UUID;

public final class MessageListener implements Listener {

    private final DrDonutMenu plugin;

    public MessageListener(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    /** Public chat: hide it from players who turned it off, except friends/follows. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onChat(AsyncChatEvent e) {
        Player source = e.getPlayer();
        e.viewers().removeIf(audience -> audience instanceof Player viewer
                && !viewer.getUniqueId().equals(source.getUniqueId())
                && !plugin.messages().canSee(viewer, Setting.PUBLIC_CHAT, source.getUniqueId()));
    }

    /** Broadcasts from other plugins (auction/order/pay) sorted by keywords from config. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onBroadcast(BroadcastMessageEvent e) {
        String text = PlainTextComponentSerializer.plainText().serialize(e.message()).toLowerCase(Locale.ROOT);
        Setting category = categorize(text);
        if (category == null) return;

        UUID actor = null;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (text.contains(p.getName().toLowerCase(Locale.ROOT))) {
                actor = p.getUniqueId();
                break;
            }
        }
        final UUID source = actor;
        e.getRecipients().removeIf(r -> r instanceof Player viewer
                && !text.contains(viewer.getName().toLowerCase(Locale.ROOT))   // messages about you always reach you
                && !plugin.messages().canSee(viewer, category, source));
    }

    private Setting categorize(String text) {
        ConfigurationSection sec = plugin.getConfig().getConfigurationSection("broadcast-filters");
        if (sec == null) return null;
        String[][] map = {{"pay", "PAY_MESSAGES"}, {"auction", "AUCTION_MESSAGES"}, {"order", "ORDER_MESSAGES"}};
        for (String[] m : map) {
            for (String word : sec.getStringList(m[0])) {
                if (!word.isEmpty() && text.contains(word.toLowerCase(Locale.ROOT))) return Setting.valueOf(m[1]);
            }
        }
        return null;
    }
}
