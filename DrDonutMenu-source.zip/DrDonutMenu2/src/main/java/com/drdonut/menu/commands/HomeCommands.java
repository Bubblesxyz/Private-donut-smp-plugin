package com.drdonut.menu.commands;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.gui.HomesMenu;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.UUID;

public final class HomeCommands implements CommandExecutor {

    private final DrDonutMenu plugin;

    public HomeCommands(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        UUID id = player.getUniqueId();
        switch (cmd.getName().toLowerCase()) {
            case "home" -> {
                if (args.length == 0) HomesMenu.open(plugin, player);
                else plugin.teleportHome(player, args[0]);
            }
            case "homes" -> HomesMenu.open(plugin, player);
            case "sethome" -> {
                String name = args.length > 0 ? args[0] : "home";
                boolean exists = plugin.homes().get(id, name) != null;
                if (!exists && plugin.homes().all(id).size() >= plugin.homes().limit(player)) {
                    plugin.error(player, "You've reached your home limit.");
                    return true;
                }
                plugin.homes().set(id, name, player.getLocation());
                plugin.ok(player, "Home '" + name + "' set!");
            }
            case "delhome" -> {
                if (args.length == 0) {
                    plugin.error(player, "Usage: /delhome <name>");
                } else if (plugin.homes().delete(id, args[0])) {
                    plugin.ok(player, "Home '" + args[0] + "' deleted.");
                } else {
                    plugin.error(player, "No home found with that name.");
                }
            }
            default -> {
            }
        }
        return true;
    }
}
