package com.drdonut.menu.gui;

import com.drdonut.menu.DrDonutMenu;
import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/** The two-column button screen (server-side Dialog, no client mod needed). */
public final class MainMenuDialog {

    private final DrDonutMenu plugin;
    private Dialog dialog;

    public MainMenuDialog(DrDonutMenu plugin) {
        this.plugin = plugin;
        rebuild();
    }

    public void rebuild() {
        int width = plugin.getConfig().getInt("menu.button-width", 150);
        List<ActionButton> buttons = new ArrayList<>();
        for (Map<?, ?> entry : plugin.getConfig().getMapList("menu.buttons")) {
            Object label = entry.get("label");
            Object command = entry.get("command");
            if (label == null || command == null) continue;
            String cmd = String.valueOf(command);
            if (cmd.startsWith("/")) cmd = cmd.substring(1);
            buttons.add(ActionButton.create(
                    Component.text(String.valueOf(label)),
                    null,
                    width,
                    DialogAction.staticAction(ClickEvent.runCommand("/" + cmd))));
        }
        dialog = Dialog.create(builder -> builder.empty()
                .base(DialogBase.builder(Component.empty()).canCloseWithEscape(true).build())
                .type(DialogType.multiAction(buttons, null, 2)));
    }

    public void open(Player player) {
        player.showDialog(dialog);
    }
}
