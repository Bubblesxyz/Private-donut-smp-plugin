package com.drdonut.menu.gui;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.settings.Setting;
import com.drdonut.menu.settings.SettingCategory;
import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Settings: a category screen, then one toggle screen per category. Vanilla dialog buttons, no resource pack needed. */
public final class SettingsMenu {

    private SettingsMenu() {}

    /** /settings - top level: one button per category. */
    public static void openCategories(DrDonutMenu plugin, Player player) {
        List<ActionButton> buttons = new ArrayList<>();
        for (SettingCategory cat : SettingCategory.values()) {
            buttons.add(ActionButton.create(
                    Component.text(cat.display()),
                    null,
                    200,
                    DialogAction.staticAction(ClickEvent.runCommand("/settings cat " + cat.name().toLowerCase()))));
        }
        ActionButton back = ActionButton.create(Component.text("Back"), null, 200,
                DialogAction.staticAction(ClickEvent.runCommand("/menu")));

        Dialog dialog = Dialog.create(builder -> builder.empty()
                .base(DialogBase.builder(Component.text("Settings")).canCloseWithEscape(true).build())
                .type(DialogType.multiAction(buttons, back, 2)));
        player.showDialog(dialog);
    }

    /** /settings cat <name> - the toggle screen for one category. */
    public static void openCategory(DrDonutMenu plugin, Player player, SettingCategory category) {
        UUID id = player.getUniqueId();
        List<ActionButton> buttons = new ArrayList<>();
        for (Setting s : Setting.in(category)) {
            boolean on = plugin.settings().get(id, s);
            Component label = Component.text(s.display() + ": ")
                    .append(Component.text(on ? "ON" : "OFF", on ? NamedTextColor.GREEN : NamedTextColor.RED));
            buttons.add(ActionButton.create(
                    label,
                    Component.text(s.description()),
                    220,
                    DialogAction.staticAction(ClickEvent.runCommand("/settings toggle " + s.key()))));
        }
        ActionButton back = ActionButton.create(Component.text("Back"), null, 200,
                DialogAction.staticAction(ClickEvent.runCommand("/settings")));

        Dialog dialog = Dialog.create(builder -> builder.empty()
                .base(DialogBase.builder(Component.text(category.display())).canCloseWithEscape(true).build())
                .type(DialogType.multiAction(buttons, back, 2)));
        player.showDialog(dialog);
    }
}
