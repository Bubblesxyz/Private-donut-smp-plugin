package com.drdonut.menu.gui;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.settings.Setting;
import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Settings screen: vanilla gray buttons, each one toggles and re-opens the screen. */
public final class SettingsMenu {

    private SettingsMenu() {}

    public static void open(DrDonutMenu plugin, Player player) {
        UUID id = player.getUniqueId();
        int width = Math.max(170, plugin.getConfig().getInt("menu.button-width", 150));

        List<ActionButton> buttons = new ArrayList<>();
        for (Setting s : Setting.values()) {
            boolean on = plugin.settings().get(id, s);
            Component label = Component.text(s.display() + ": ")
                    .append(Component.text(on ? "ON" : "OFF", on ? NamedTextColor.GREEN : NamedTextColor.RED));
            buttons.add(ActionButton.create(
                    label,
                    Component.text(s.description()),
                    width,
                    DialogAction.staticAction(ClickEvent.runCommand("/settings toggle " + s.key()))));
        }

        ActionButton back = ActionButton.create(
                Component.text("Back"),
                null,
                200,
                DialogAction.staticAction(ClickEvent.runCommand("/menu")));

        Dialog dialog = Dialog.create(builder -> builder.empty()
                .base(DialogBase.builder(Component.text("Settings")).canCloseWithEscape(true).build())
                .type(DialogType.multiAction(buttons, back, 2)));
        player.showDialog(dialog);
    }
}
