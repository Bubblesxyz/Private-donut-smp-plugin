package com.drdonut.menu.gui;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.settings.Setting;
import com.drdonut.menu.settings.SettingCategory;
import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * Settings dialogs: a single-column category list with a separate "Close" button
 * below it, then a single-column toggle list per category with a "Back" button
 * below it - matching the reference screenshot layout.
 */
public final class SettingsMenu {

    private static final int WIDTH = 320;

    private SettingsMenu() {}

    /** /settings - top level: one full-width button per category, "Close" on its own below. */
    public static void openCategories(DrDonutMenu plugin, Player player) {
        List<ActionButton> buttons = new ArrayList<>();
        for (SettingCategory cat : SettingCategory.values()) {
            buttons.add(ActionButton.create(
                    Component.text(cat.display()),
                    null,
                    WIDTH,
                    DialogAction.staticAction(ClickEvent.runCommand("/settings cat " + cat.name().toLowerCase()))));
        }
        // No command to run on "Close" - just dismisses the dialog.
        ActionButton close = ActionButton.create(Component.text("Close"), null, WIDTH,
                DialogAction.staticAction(ClickEvent.suggestCommand("")));

        Dialog dialog = Dialog.create(builder -> builder.empty()
                .base(DialogBase.builder(Component.text("Settings")).canCloseWithEscape(true).build())
                .type(DialogType.multiAction(buttons, close, 1)));
        player.showDialog(dialog);
    }

    /** /settings cat <name> - the toggle screen for one category, "Back" on its own below. */
    public static void openCategory(DrDonutMenu plugin, Player player, SettingCategory category) {
        UUID id = player.getUniqueId();
        List<ActionButton> buttons = new ArrayList<>();
        for (Setting s : Setting.in(category)) {
            boolean on = plugin.settings().get(id, s);
            Component label = Component.text(s.display() + ": ")
                    .append(Component.text(on ? "ON" : "OFF", on ? NamedTextColor.GREEN : NamedTextColor.RED));
            buttons.add(ActionButton.create(
                    label,
                    Component.text(s.description()),
                    WIDTH,
                    DialogAction.staticAction(ClickEvent.runCommand("/settings toggle " + s.key()))));
        }
        ActionButton back = ActionButton.create(Component.text("Back"), null, WIDTH,
                DialogAction.staticAction(ClickEvent.runCommand("/settings")));

        Dialog dialog = Dialog.create(builder -> builder.empty()
                .base(DialogBase.builder(Component.text(category.display())).canCloseWithEscape(true).build())
                .type(DialogType.multiAction(buttons, back, 1)));
        player.showDialog(dialog);
    }
}
