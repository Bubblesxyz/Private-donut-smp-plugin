package com.drdonut.menu;

import io.papermc.paper.dialog.Dialog;
import io.papermc.paper.plugin.bootstrap.BootstrapContext;
import io.papermc.paper.plugin.bootstrap.PluginBootstrap;
import io.papermc.paper.plugin.lifecycle.event.types.LifecycleEvents;
import io.papermc.paper.registry.RegistryKey;
import io.papermc.paper.registry.data.dialog.ActionButton;
import io.papermc.paper.registry.data.dialog.DialogBase;
import io.papermc.paper.registry.data.dialog.action.DialogAction;
import io.papermc.paper.registry.data.dialog.type.DialogType;
import io.papermc.paper.registry.event.RegistryEvents;
import io.papermc.paper.registry.keys.DialogKeys;
import io.papermc.paper.registry.keys.tags.DialogTagKeys;
import io.papermc.paper.tag.PostFlattenTagRegistrar;
import io.papermc.paper.registry.TypedKey;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;

import java.util.List;

/**
 * Registers a copy of the main menu with Minecraft's built-in "Quick Actions" key
 * (added in 1.21.6, default key G) and the pause-screen "Server Links" slot, so the
 * menu opens without typing /menu. This is a fixed snapshot of the default buttons:
 * changing menu.buttons in config.yml later will NOT change this copy, only /menu.
 */
public final class DrDonutMenuBootstrap implements PluginBootstrap {

    // Instant, one-click menu for the Quick Actions key - a fixed snapshot of the default buttons.
    private static final TypedKey<Dialog> QUICK_ACTION_KEY = DialogKeys.create(net.kyori.adventure.key.Key.key("drdonutmenu:main_menu"));
    // Pause-screen entry: shows as "Donut SMP" and runs the real /menu command, so it always
    // matches whatever is currently in config.yml (unlike the quick-action copy above).
    private static final TypedKey<Dialog> PAUSE_MENU_KEY = DialogKeys.create(net.kyori.adventure.key.Key.key("drdonutmenu:pause_menu"));

    @Override
    public void bootstrap(BootstrapContext context) {
        // Same defaults as config.yml's menu.buttons.
        record Btn(String label, String command) {}
        List<Btn> defaults = List.of(
                new Btn("Homes", "home"), new Btn("Auction", "ah"),
                new Btn("Friends", "friend"), new Btn("Orders", "order"),
                new Btn("Sell", "sell"), new Btn("Pay", "pay"),
                new Btn("RTP", "rtpp"), new Btn("Stats", "stats"),
                new Btn("Leaderboards", "stats"), new Btn("Settings", "setting")
        );

        context.getLifecycleManager().registerEventHandler(RegistryEvents.DIALOG.compose(), event -> {
            event.registry().register(QUICK_ACTION_KEY, builder -> {
                List<ActionButton> buttons = defaults.stream()
                        .map(b -> ActionButton.create(Component.text(b.label()), null, 150,
                                DialogAction.staticAction(ClickEvent.runCommand("/" + b.command()))))
                        .toList();
                builder.base(DialogBase.builder(Component.empty()).canCloseWithEscape(true).build())
                        .type(DialogType.multiAction(buttons, null, 2));
            });

            event.registry().register(PAUSE_MENU_KEY, builder -> {
                ActionButton open = ActionButton.create(Component.text("Open Menu"), null, 200,
                        DialogAction.staticAction(ClickEvent.runCommand("/menu")));
                builder.base(DialogBase.builder(Component.text("Donut SMP")).canCloseWithEscape(true).build())
                        .type(DialogType.multiAction(List.of(open), null, 1));
            });
        });

        context.getLifecycleManager().registerEventHandler(
                LifecycleEvents.TAGS.postFlatten(RegistryKey.DIALOG), event -> {
                    PostFlattenTagRegistrar<Dialog> registrar = event.registrar();
                    registrar.addToTag(DialogTagKeys.QUICK_ACTIONS, List.of(QUICK_ACTION_KEY));
                    registrar.addToTag(DialogTagKeys.PAUSE_SCREEN_ADDITIONS, List.of(PAUSE_MENU_KEY));
                });
    }
}
