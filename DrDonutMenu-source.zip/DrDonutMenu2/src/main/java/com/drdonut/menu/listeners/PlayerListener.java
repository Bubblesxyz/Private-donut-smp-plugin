package com.drdonut.menu.listeners;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.economy.VaultHook;
import com.drdonut.menu.settings.Setting;
import org.bukkit.inventory.ItemStack;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.entity.EnderCrystal;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.Material;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public final class PlayerListener implements Listener {

    private final DrDonutMenu plugin;

    public PlayerListener(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    // ---- join / quit messages (per-player toggle, friends always shown) ----
    @EventHandler(priority = EventPriority.HIGH)
    public void onJoin(PlayerJoinEvent e) {
        Player joined = e.getPlayer();
        plugin.syncNightVision(joined, false);
        plugin.applyPlayerVisibility(joined);
        plugin.scoreboards().refresh(joined);
        for (Player other : Bukkit.getOnlinePlayers()) {
            if (other.equals(joined)) continue;
            if (!plugin.settings().get(other.getUniqueId(), Setting.PLAYER_VISIBILITY)) other.hidePlayer(plugin, joined);
            if (!plugin.settings().get(joined.getUniqueId(), Setting.PLAYER_VISIBILITY)) joined.hidePlayer(plugin, other);
        }
        Component msg = e.joinMessage();
        e.joinMessage(null);
        broadcastFiltered(msg, e.getPlayer());
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onQuit(PlayerQuitEvent e) {
        Component msg = e.quitMessage();
        e.quitMessage(null);
        broadcastFiltered(msg, e.getPlayer());
    }

    private void broadcastFiltered(Component msg, Player subject) {
        if (msg == null) return;
        for (Player viewer : Bukkit.getOnlinePlayers()) {
            if (plugin.messages().canSee(viewer, Setting.JOIN_MESSAGES, subject.getUniqueId())) {
                viewer.sendMessage(msg);
            }
        }
        Bukkit.getConsoleSender().sendMessage(msg);
    }

    // ---- night vision survives death and milk ----
    @EventHandler
    public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTask(plugin, () -> {
            plugin.syncNightVision(p, false);
            giveChainmailIfEnabled(p);
        });
    }

    private void giveChainmailIfEnabled(Player p) {
        if (!plugin.settings().get(p.getUniqueId(), Setting.CHAINMAIL_ON_RESPAWN)) return;
        VaultHook vault = VaultHook.create(plugin);
        double cost = plugin.getConfig().getDouble("chainmail-on-respawn.cost", 1000.0);
        if (vault == null || !vault.has(p, cost) || !vault.withdraw(p, cost)) return;
        p.getInventory().setHelmet(new ItemStack(Material.CHAINMAIL_HELMET));
        p.getInventory().setChestplate(new ItemStack(Material.CHAINMAIL_CHESTPLATE));
        p.getInventory().setLeggings(new ItemStack(Material.CHAINMAIL_LEGGINGS));
        p.getInventory().setBoots(new ItemStack(Material.CHAINMAIL_BOOTS));
        plugin.info(p, "You were given chainmail armor for " + vault.format(cost) + ".");
    }

    @EventHandler
    public void onConsume(PlayerItemConsumeEvent e) {
        if (e.getItem().getType() != Material.MILK_BUCKET) return;
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(plugin, () -> plugin.syncNightVision(p, false), 2L);
    }

    // ---- fast crystals ----
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onCrystalHit(EntityDamageByEntityEvent e) {
        if (!(e.getEntity() instanceof EnderCrystal crystal)) return;
        Player attacker = attackerOf(e);
        if (attacker == null || !plugin.settings().get(attacker.getUniqueId(), Setting.FAST_CRYSTALS)) return;

        e.setCancelled(true);
        Location loc = crystal.getLocation();
        crystal.remove();
        float power = (float) plugin.getConfig().getDouble("crystals.explosion-power", 6.0);
        loc.getWorld().createExplosion(loc, power, false, true, attacker);
    }

    // ---- totem trail ----
    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Location from = e.getFrom();
        Location to = e.getTo();
        if (to == null) return;
        if (from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY()
                && from.getBlockZ() == to.getBlockZ()) return;
        Player p = e.getPlayer();
        if (!plugin.settings().get(p.getUniqueId(), Setting.TOTEM_TRAIL)) return;
        p.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, from.clone().add(0, 0.2, 0), 6, 0.25, 0.1, 0.25, 0.2);
    }

    static Player attackerOf(EntityDamageByEntityEvent e) {
        Entity damager = e.getDamager();
        if (damager instanceof Player p) return p;
        if (damager instanceof Projectile proj && proj.getShooter() instanceof Player p) return p;
        return null;
    }
}
