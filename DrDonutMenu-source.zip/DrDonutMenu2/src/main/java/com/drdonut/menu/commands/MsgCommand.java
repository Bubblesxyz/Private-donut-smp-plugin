package com.drdonut.menu.commands;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.settings.Setting;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class MsgCommand implements CommandExecutor {

    private final DrDonutMenu plugin;

    public MsgCommand(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player me)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (args.length < 2) {
            plugin.error(me, "Usage: /msg <player> <message>");
            return true;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            plugin.error(me, "Player not found.");
            return true;
        }
        if (target.equals(me)) {
            plugin.error(me, "You can't message yourself.");
            return true;
        }
        // Friends/follows always get through, even if the target turned private messages off.
        if (!plugin.messages().canSee(target, Setting.PRIVATE_MESSAGES, me.getUniqueId())) {
            plugin.error(me, target.getName() + " has private messages disabled.");
            return true;
        }
        String text = String.join(" ", java.util.Arrays.copyOfRange(args, 1, args.length));
        me.sendMessage(Component.text("[me -> " + target.getName() + "] ", NamedTextColor.LIGHT_PURPLE)
                .append(Component.text(text, NamedTextColor.WHITE)));
        target.sendMessage(Component.text("[" + me.getName() + " -> me] ", NamedTextColor.LIGHT_PURPLE)
                .append(Component.text(text, NamedTextColor.WHITE)));
        return true;
    }
}
