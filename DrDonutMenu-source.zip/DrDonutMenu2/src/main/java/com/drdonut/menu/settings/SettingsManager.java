package com.drdonut.menu.settings;

import com.drdonut.menu.DrDonutMenu;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class SettingsManager {

    private final DrDonutMenu plugin;
    private final File file;
    private final Map<UUID, EnumMap<Setting, Boolean>> data = new HashMap<>();

    public SettingsManager(DrDonutMenu plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "players.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        for (String id : yml.getKeys(false)) {
            ConfigurationSection sec = yml.getConfigurationSection(id);
            if (sec == null) continue;
            UUID uuid;
            try {
                uuid = UUID.fromString(id);
            } catch (IllegalArgumentException ex) {
                continue;
            }
            EnumMap<Setting, Boolean> map = new EnumMap<>(Setting.class);
            for (Setting s : Setting.values()) {
                if (sec.contains(s.key())) map.put(s, sec.getBoolean(s.key()));
            }
            data.put(uuid, map);
        }
    }

    public boolean get(UUID uuid, Setting setting) {
        EnumMap<Setting, Boolean> map = data.get(uuid);
        if (map != null && map.containsKey(setting)) return map.get(setting);
        return plugin.getConfig().getBoolean("settings.defaults." + setting.key(), setting.def());
    }

    public void set(UUID uuid, Setting setting, boolean value) {
        data.computeIfAbsent(uuid, k -> new EnumMap<>(Setting.class)).put(setting, value);
        save();
    }

    public boolean toggle(UUID uuid, Setting setting) {
        boolean now = !get(uuid, setting);
        set(uuid, setting, now);
        return now;
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        for (Map.Entry<UUID, EnumMap<Setting, Boolean>> e : data.entrySet()) {
            for (Map.Entry<Setting, Boolean> s : e.getValue().entrySet()) {
                yml.set(e.getKey() + "." + s.getKey().key(), s.getValue());
            }
        }
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save players.yml: " + ex.getMessage());
        }
    }
}
