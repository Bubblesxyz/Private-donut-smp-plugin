package com.drdonut.menu.listeners;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.settings.Setting;
import org.bukkit.Location;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Phantom;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;

/** Per-player natural mob / phantom spawn switches. */
public final class SpawnListener implements Listener {

    private final DrDonutMenu plugin;

    public SpawnListener(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent e) {
        if (e.getSpawnReason() != CreatureSpawnEvent.SpawnReason.NATURAL) return;
        Entity entity = e.getEntity();
        boolean phantom = entity instanceof Phantom;
        boolean hostile = entity instanceof Enemy;
        if (!phantom && !hostile) return;

        Location loc = e.getLocation();
        int chunkRadius = plugin.getConfig().getInt("mob-spawn.radius-chunks", 2);
        double phantomRadius = plugin.getConfig().getDouble("mob-spawn.phantom-radius-blocks", 64);
        double phantomSq = phantomRadius * phantomRadius;
        int cx = loc.getBlockX() >> 4;
        int cz = loc.getBlockZ() >> 4;

        for (Player p : loc.getWorld().getPlayers()) {
            Location pl = p.getLocation();
            if (hostile
                    && Math.abs((pl.getBlockX() >> 4) - cx) <= chunkRadius
                    && Math.abs((pl.getBlockZ() >> 4) - cz) <= chunkRadius
                    && plugin.settings().get(p.getUniqueId(), Setting.NO_MOB_SPAWNS)) {
                e.setCancelled(true);
                return;
            }
            if (phantom && pl.distanceSquared(loc) <= phantomSq
                    && plugin.settings().get(p.getUniqueId(), Setting.NO_PHANTOMS)) {
                e.setCancelled(true);
                return;
            }
        }
    }
}
