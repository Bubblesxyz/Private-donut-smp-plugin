package com.drdonut.menu.settings;

import org.bukkit.Material;

public enum Setting {
    PUBLIC_CHAT("public-chat", "Public Chat", "See public chat (friends/follows always shown)", Material.OAK_SIGN, true),
    ORDER_MESSAGES("order-messages", "Order Messages", "See order announcements", Material.CHEST, true),
    AUCTION_MESSAGES("auction-messages", "Auction Messages", "See auction listing announcements", Material.GOLD_INGOT, true),
    PAY_MESSAGES("pay-messages", "Pay Messages", "See /pay messages", Material.EMERALD, true),
    JOIN_MESSAGES("join-messages", "Join Messages", "See join/leave messages", Material.PAPER, true),
    SOUND_EFFECTS("sound-effects", "Sound Effects", "Menu and teleport sounds", Material.NOTE_BLOCK, true),
    AUTO_TPA("auto-tpa", "Auto-Accept TPA", "Automatically accept teleport requests sent to you", Material.ENDER_PEARL, false),
    NO_MOB_SPAWNS("no-mob-spawns", "No Mob Spawns", "No hostile mobs spawn near you", Material.ZOMBIE_HEAD, false),
    NO_PHANTOMS("no-phantoms", "No Phantoms", "No phantoms spawn near you", Material.PHANTOM_MEMBRANE, false),
    TOTEM_TRAIL("totem-trail", "Totem Trail", "Totem particles follow you", Material.TOTEM_OF_UNDYING, false),
    FAST_CRYSTALS("fast-crystals", "Fast Crystals", "End crystals break instantly when hit", Material.END_CRYSTAL, false),
    NIGHT_VISION("night-vision", "Night Vision", "Permanent night vision", Material.GOLDEN_CARROT, false);

    private final String key;
    private final String display;
    private final String description;
    private final Material icon;
    private final boolean def;

    Setting(String key, String display, String description, Material icon, boolean def) {
        this.key = key;
        this.display = display;
        this.description = description;
        this.icon = icon;
        this.def = def;
    }

    public static Setting byKey(String key) {
        for (Setting s : values()) if (s.key.equalsIgnoreCase(key)) return s;
        return null;
    }

    public String key() { return key; }
    public String display() { return display; }
    public String description() { return description; }
    public Material icon() { return icon; }
    public boolean def() { return def; }
}
