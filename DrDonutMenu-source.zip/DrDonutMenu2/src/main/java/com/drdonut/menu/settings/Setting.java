package com.drdonut.menu.settings;

import org.bukkit.Material;

import static com.drdonut.menu.settings.SettingCategory.*;

public enum Setting {
    // ---- Chat ----
    PUBLIC_CHAT(CHAT, "public-chat", "Public Chat", "See public chat (friends/follows always shown)", Material.OAK_SIGN, true),
    PRIVATE_MESSAGES(CHAT, "private-messages", "Private Messages", "Receive /msg from other players", Material.PAPER, true),
    SERVER_BROADCASTS(CHAT, "server-broadcasts", "Server Broadcasts", "See general server broadcast messages", Material.BOOK, true),
    HOTBAR_MESSAGES(CHAT, "hotbar-messages", "Hotbar Messages", "Show action-bar messages (like RTP countdowns)", Material.CLOCK, true),
    TEAM_CHAT(CHAT, "team-chat", "Team Chat", "Reserved for a future teams system", Material.WHITE_BANNER, true),

    // ---- Notifications ----
    PAY_MESSAGES(NOTIFICATIONS, "pay-messages", "Pay Messages", "See /pay messages", Material.EMERALD, true),
    ORDER_MESSAGES(NOTIFICATIONS, "order-messages", "Order Messages", "See order announcements", Material.CHEST, true),
    AUCTION_MESSAGES(NOTIFICATIONS, "auction-messages", "Auction Messages", "See auction listing announcements", Material.GOLD_INGOT, true),
    AUCTION_QUICK_BUY(NOTIFICATIONS, "auction-quick-buy", "Auction Quick Buy", "Reserved for a future auction house", Material.HOPPER, false),
    BOUNTY_ALERTS(NOTIFICATIONS, "bounty-alerts", "Bounty Alerts", "Reserved for a future bounty system", Material.TARGET, true),
    JOIN_MESSAGES(NOTIFICATIONS, "join-messages", "Join Messages", "See join/leave messages", Material.PAPER, true),
    SOUND_EFFECTS(NOTIFICATIONS, "sound-effects", "Sound Effects", "Menu and teleport sounds", Material.NOTE_BLOCK, true),
    TEAM_INVITES(NOTIFICATIONS, "team-invites", "Team Invites", "Reserved for a future teams system", Material.SHIELD, true),

    // ---- PvP ----
    DUEL_REQUESTS(PVP, "duel-requests", "Duel Requests", "Reserved for a future duel system", Material.IRON_SWORD, true),
    FAST_CRYSTALS(PVP, "fast-crystals", "Fast Crystals", "End crystals break instantly when hit", Material.END_CRYSTAL, false),

    // ---- Visuals ----
    TOTEM_TRAIL(VISUALS, "totem-trail", "Totem Trail", "Totem particles follow you", Material.TOTEM_OF_UNDYING, false),
    NIGHT_VISION(VISUALS, "night-vision", "Night Vision", "Permanent night vision", Material.GOLDEN_CARROT, false),
    CHAINMAIL_ON_RESPAWN(VISUALS, "chainmail-on-respawn", "Chainmail on Respawn", "Costs money on respawn (needs Vault)", Material.CHAINMAIL_CHESTPLATE, false),

    // ---- Privacy ----
    PLAYER_VISIBILITY(PRIVACY, "player-visibility", "Show Other Players", "See other players in the world and tab list", Material.ENDER_EYE, true),
    NO_MOB_SPAWNS(PRIVACY, "no-mob-spawns", "No Mob Spawns", "No hostile mobs spawn near you", Material.ZOMBIE_HEAD, false),
    NO_PHANTOMS(PRIVACY, "no-phantoms", "No Phantoms", "No phantoms spawn near you", Material.PHANTOM_MEMBRANE, false),
    QUIET_SPAWN(PRIVACY, "quiet-spawn", "Quiet Teleports", "No sounds/messages on home or RTP teleports", Material.FEATHER, false),
    SHOW_RTP_COORDS(PRIVACY, "show-rtp-coords", "Show RTP Coordinates", "Show your coordinates after RTP", Material.COMPASS, true),
    AUTO_TPA(PRIVACY, "auto-tpa", "Auto-Accept TPA", "Automatically accept teleport requests sent to you", Material.ENDER_PEARL, false),

    // ---- Scoreboard ----
    SCOREBOARD_VISIBLE(SCOREBOARD, "scoreboard-visible", "Show Scoreboard", "Show the sidebar scoreboard", Material.OAK_SIGN, true);

    private final SettingCategory category;
    private final String key;
    private final String display;
    private final String description;
    private final Material icon;
    private final boolean def;

    Setting(SettingCategory category, String key, String display, String description, Material icon, boolean def) {
        this.category = category;
        this.key = key;
        this.display = display;
        this.description = description;
        this.icon = icon;
        this.def = def;
    }

    public static Setting byKey(String key) {
        for (Setting s : values()) if (s.key.equalsIgnoreCase(key)) return s;
        return null;
    }

    public static java.util.List<Setting> in(SettingCategory category) {
        java.util.List<Setting> list = new java.util.ArrayList<>();
        for (Setting s : values()) if (s.category == category) list.add(s);
        return list;
    }

    public SettingCategory category() { return category; }
    public String key() { return key; }
    public String display() { return display; }
    public String description() { return description; }
    public Material icon() { return icon; }
    public boolean def() { return def; }
}
