package com.drdonut.menu.commands;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.settings.Setting;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public final class TpaCommands implements CommandExecutor {

    private record Request(UUID from, long expiresAt) {}

    private final DrDonutMenu plugin;
    /** target -> latest request */
    private final Map<UUID, Request> requests = new HashMap<>();

    public TpaCommands(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player me)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        switch (cmd.getName().toLowerCase()) {
            case "tpa" -> send(me, args);
            case "tpaccept" -> accept(me);
            case "tpdeny" -> deny(me);
            default -> {
            }
        }
        return true;
    }

    private void send(Player me, String[] args) {
        if (args.length < 1) {
            plugin.error(me, "Usage: /tpa <player>");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[0]);
        if (target == null) {
            plugin.error(me, "Player not found.");
            return;
        }
        if (target.equals(me)) {
            plugin.error(me, "You can't teleport to yourself.");
            return;
        }
        // Target chose to auto-accept requests: teleport straight away.
        if (plugin.settings().get(target.getUniqueId(), Setting.AUTO_TPA)) {
            plugin.ok(me, target.getName() + " auto-accepted your request.");
            plugin.info(target, me.getName() + " teleported to you (auto-accept is on).");
            me.teleportAsync(target.getLocation());
            plugin.whoosh(me);
            return;
        }
        long ttl = plugin.getConfig().getLong("tpa.expire-seconds", 60) * 1000L;
        requests.put(target.getUniqueId(), new Request(me.getUniqueId(), System.currentTimeMillis() + ttl));
        plugin.ok(me, "Teleport request sent to " + target.getName() + ".");
        plugin.send(target, Component.text(me.getName() + " wants to teleport to you. ", NamedTextColor.YELLOW)
                .append(Component.text("[Accept]", NamedTextColor.GREEN).clickEvent(ClickEvent.runCommand("/tpaccept")))
                .append(Component.text(" "))
                .append(Component.text("[Deny]", NamedTextColor.RED).clickEvent(ClickEvent.runCommand("/tpdeny"))));
    }

    private Player takeRequester(Player me) {
        Request r = requests.remove(me.getUniqueId());
        if (r == null || r.expiresAt() < System.currentTimeMillis()) {
            plugin.error(me, "You have no pending teleport requests.");
            return null;
        }
        Player from = Bukkit.getPlayer(r.from());
        if (from == null) {
            plugin.error(me, "That player is no longer online.");
            return null;
        }
        return from;
    }

    private void accept(Player me) {
        Player from = takeRequester(me);
        if (from == null) return;
        plugin.ok(me, "Accepted " + from.getName() + "'s request.");
        plugin.ok(from, me.getName() + " accepted your request.");
        from.teleportAsync(me.getLocation());
        plugin.whoosh(from);
    }

    private void deny(Player me) {
        Player from = takeRequester(me);
        if (from == null) return;
        plugin.info(me, "Denied " + from.getName() + "'s request.");
        plugin.error(from, me.getName() + " denied your request.");
    }
}
