package com.drdonut.menu.economy;

import net.milkbowl.vault.economy.Economy;
import net.milkbowl.vault.economy.EconomyResponse;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

/** Thin wrapper so Vault is only touched when it is installed. */
public final class VaultHook {

    private final Economy economy;

    private VaultHook(Economy economy) {
        this.economy = economy;
    }

    /** @return a hook, or null if no Vault economy is registered. */
    public static VaultHook create(JavaPlugin plugin) {
        if (plugin.getServer().getPluginManager().getPlugin("Vault") == null) return null;
        RegisteredServiceProvider<Economy> rsp = plugin.getServer().getServicesManager().getRegistration(Economy.class);
        return rsp == null ? null : new VaultHook(rsp.getProvider());
    }

    public boolean has(OfflinePlayer p, double amount) {
        return economy.has(p, amount);
    }

    public boolean withdraw(OfflinePlayer p, double amount) {
        EconomyResponse r = economy.withdrawPlayer(p, amount);
        return r.transactionSuccess();
    }

    public boolean deposit(OfflinePlayer p, double amount) {
        EconomyResponse r = economy.depositPlayer(p, amount);
        return r.transactionSuccess();
    }

    public String format(double amount) {
        return economy.format(amount);
    }
}
