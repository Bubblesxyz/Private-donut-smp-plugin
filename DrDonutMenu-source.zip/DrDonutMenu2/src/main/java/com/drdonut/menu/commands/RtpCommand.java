package com.drdonut.menu.commands;

import com.drdonut.menu.DrDonutMenu;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class RtpCommand implements CommandExecutor {

    private final DrDonutMenu plugin;

    public RtpCommand(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        plugin.rtp().start(player);
        return true;
    }
}
