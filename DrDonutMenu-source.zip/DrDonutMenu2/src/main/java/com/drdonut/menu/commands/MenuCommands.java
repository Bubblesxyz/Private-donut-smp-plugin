package com.drdonut.menu.commands;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.gui.SettingsMenu;
import com.drdonut.menu.settings.Setting;
import com.drdonut.menu.settings.SettingCategory;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class MenuCommands implements CommandExecutor {

    private final DrDonutMenu plugin;

    public MenuCommands(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!cmd.getName().equalsIgnoreCase("settings")) {
            plugin.mainMenu().open(player);
            return true;
        }

        if (args.length >= 1 && args[0].equalsIgnoreCase("cat") && args.length >= 2) {
            SettingCategory cat = parseCategory(args[1]);
            if (cat != null) {
                plugin.click(player);
                SettingsMenu.openCategory(plugin, player, cat);
                return true;
            }
        }

        if (args.length >= 2 && args[0].equalsIgnoreCase("toggle")) {
            Setting s = Setting.byKey(args[1]);
            if (s != null) {
                plugin.settings().toggle(player.getUniqueId(), s);
                plugin.click(player);
                plugin.onSettingChanged(player, s);
                SettingsMenu.openCategory(plugin, player, s.category());
                return true;
            }
        }

        SettingsMenu.openCategories(plugin, player);
        return true;
    }

    private SettingCategory parseCategory(String raw) {
        for (SettingCategory c : SettingCategory.values()) {
            if (c.name().equalsIgnoreCase(raw)) return c;
        }
        return null;
    }
}
