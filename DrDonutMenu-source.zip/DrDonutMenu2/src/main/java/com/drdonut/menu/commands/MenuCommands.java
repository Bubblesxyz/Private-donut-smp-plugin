package com.drdonut.menu.commands;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.gui.SettingsMenu;
import com.drdonut.menu.settings.Setting;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public final class MenuCommands implements CommandExecutor {

    private final DrDonutMenu plugin;

    public MenuCommands(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this command.");
            return true;
        }
        if (!cmd.getName().equalsIgnoreCase("settings")) {
            plugin.mainMenu().open(player);
            return true;
        }

        // Used by the settings buttons: /settings toggle <key>
        if (args.length >= 2 && args[0].equalsIgnoreCase("toggle")) {
            Setting s = Setting.byKey(args[1]);
            if (s != null) {
                plugin.settings().toggle(player.getUniqueId(), s);
                plugin.click(player);
                if (s == Setting.NIGHT_VISION) plugin.syncNightVision(player, true);
            }
        }
        SettingsMenu.open(plugin, player);
        return true;
    }
}
