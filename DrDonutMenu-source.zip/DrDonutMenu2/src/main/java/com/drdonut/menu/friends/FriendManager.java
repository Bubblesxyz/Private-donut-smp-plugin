package com.drdonut.menu.friends;

import com.drdonut.menu.DrDonutMenu;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.*;

public final class FriendManager {

    private final DrDonutMenu plugin;
    private final File file;
    private final Map<UUID, Set<UUID>> friends = new HashMap<>();
    private final Map<UUID, Set<UUID>> following = new HashMap<>();
    /** target -> people who asked to be their friend (not saved). */
    private final Map<UUID, Set<UUID>> requests = new HashMap<>();

    public FriendManager(DrDonutMenu plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "friends.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration yml = YamlConfiguration.loadConfiguration(file);
        read(yml.getConfigurationSection("friends"), friends);
        read(yml.getConfigurationSection("following"), following);
    }

    private void read(ConfigurationSection sec, Map<UUID, Set<UUID>> into) {
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            try {
                UUID owner = UUID.fromString(key);
                Set<UUID> set = new LinkedHashSet<>();
                for (String s : sec.getStringList(key)) set.add(UUID.fromString(s));
                into.put(owner, set);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    public void save() {
        YamlConfiguration yml = new YamlConfiguration();
        write(yml, "friends", friends);
        write(yml, "following", following);
        try {
            plugin.getDataFolder().mkdirs();
            yml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("Could not save friends.yml: " + ex.getMessage());
        }
    }

    private void write(YamlConfiguration yml, String path, Map<UUID, Set<UUID>> map) {
        for (Map.Entry<UUID, Set<UUID>> e : map.entrySet()) {
            List<String> list = new ArrayList<>();
            for (UUID u : e.getValue()) list.add(u.toString());
            yml.set(path + "." + e.getKey(), list);
        }
    }

    // ---- queries ----
    public boolean areFriends(UUID a, UUID b) {
        return friends.getOrDefault(a, Set.of()).contains(b);
    }

    public boolean isFollowing(UUID follower, UUID target) {
        return following.getOrDefault(follower, Set.of()).contains(target);
    }

    /** True if viewer is friends with source or follows them. */
    public boolean sees(UUID viewer, UUID source) {
        return areFriends(viewer, source) || isFollowing(viewer, source);
    }

    public Set<UUID> friendsOf(UUID id) {
        return friends.getOrDefault(id, Set.of());
    }

    public Set<UUID> followingOf(UUID id) {
        return following.getOrDefault(id, Set.of());
    }

    public int followerCount(UUID id) {
        int n = 0;
        for (Set<UUID> s : following.values()) if (s.contains(id)) n++;
        return n;
    }

    public Set<UUID> requestsFor(UUID id) {
        return requests.getOrDefault(id, Set.of());
    }

    // ---- changes ----
    public void addFriends(UUID a, UUID b) {
        friends.computeIfAbsent(a, k -> new LinkedHashSet<>()).add(b);
        friends.computeIfAbsent(b, k -> new LinkedHashSet<>()).add(a);
        removeRequest(a, b);
        removeRequest(b, a);
        save();
    }

    public void removeFriends(UUID a, UUID b) {
        friends.getOrDefault(a, new HashSet<>()).remove(b);
        friends.getOrDefault(b, new HashSet<>()).remove(a);
        save();
    }

    public void follow(UUID follower, UUID target) {
        following.computeIfAbsent(follower, k -> new LinkedHashSet<>()).add(target);
        save();
    }

    public void unfollow(UUID follower, UUID target) {
        following.getOrDefault(follower, new HashSet<>()).remove(target);
        save();
    }

    public void addRequest(UUID from, UUID to) {
        requests.computeIfAbsent(to, k -> new LinkedHashSet<>()).add(from);
    }

    public boolean hasRequest(UUID from, UUID to) {
        return requests.getOrDefault(to, Set.of()).contains(from);
    }

    public void removeRequest(UUID from, UUID to) {
        Set<UUID> set = requests.get(to);
        if (set != null) set.remove(from);
    }
}
