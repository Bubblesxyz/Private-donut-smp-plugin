package com.drdonut.menu.listeners;

import com.drdonut.menu.DrDonutMenu;
import com.drdonut.menu.settings.Setting;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.DisplaySlot;
import org.bukkit.scoreboard.Objective;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

/** Minimal per-player sidebar, shown or hidden per the Scoreboard setting. */
public final class ScoreboardService {

    private final DrDonutMenu plugin;

    public ScoreboardService(DrDonutMenu plugin) {
        this.plugin = plugin;
    }

    public void refresh(Player player) {
        if (!plugin.settings().get(player.getUniqueId(), Setting.SCOREBOARD_VISIBLE)) {
            player.setScoreboard(Bukkit.getScoreboardManager().getNewScoreboard());
            return;
        }
        Scoreboard board = Bukkit.getScoreboardManager().getNewScoreboard();
        Objective obj = board.registerNewObjective("donutsmp", "dummy",
                Component.text("Donut SMP", NamedTextColor.GOLD));
        obj.setDisplaySlot(DisplaySlot.SIDEBAR);

        String[] lines = {"§7" + player.getName(), "§8------------", "§eHomes: §f" + plugin.homes().all(player.getUniqueId()).size()};
        int score = lines.length;
        for (String line : lines) {
            Team team = board.registerNewTeam("l" + score);
            team.addEntry(line);
            team.prefix(Component.text(""));
            obj.getScore(line).setScore(score--);
        }
        player.setScoreboard(board);
    }
}
