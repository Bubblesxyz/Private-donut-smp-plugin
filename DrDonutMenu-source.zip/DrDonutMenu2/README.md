# DrDonutMenu 2.1 (Paper 1.21.11)

UNTESTED: written without access to compile against the real Paper API. Syntax-checked
only (no real errors found). Build it and report any compile errors so they can be fixed.

Build the jar (pick one):
- Computer: install JDK 21 + Maven, then run `mvn package`. Jar = target/DrDonutMenu.jar
- No install: upload this folder to a new GitHub repo (or use the DrDonutMenu-source.zip
  workflow from before). Actions tab -> "Build plugin" -> download the DrDonutMenu artifact.

New in 2.1:
- /menu now also opens from Minecraft's built-in Quick Actions key (default G) and the
  pause-screen extra button, via a plugin bootstrapper (paper-plugin.yml). This is a fixed
  copy of the default buttons; editing config.yml's menu.buttons won't change these two
  without a plugin update.
- /settings is now a category screen (Chat, Notifications, PvP, Visuals, Privacy,
  Scoreboard) with a toggle screen per category - 24 settings total, adapted from the
  PlayerSettings plugin you sent. Several (duels, teams, bounties, auction quick-buy) are
  stored toggles with no effect yet, since those systems don't exist in this plugin -
  they're reserved for when they're added.
- Friends screen is now a dialog matching your reference image (Add Friend / View
  Friends / Back) instead of a chest inventory.
- New: /msg (private messages, respects the Private Messages setting), a basic sidebar
  scoreboard, "Show Other Players" (hide/show players per-viewer), "Quiet Teleports",
  "Show RTP Coordinates", and Chainmail on Respawn (needs Vault + an economy plugin).

Not done: the flat black button skin from your screenshots. That needs a resource pack
to reskin the vanilla button texture - ask if you want that built too.
