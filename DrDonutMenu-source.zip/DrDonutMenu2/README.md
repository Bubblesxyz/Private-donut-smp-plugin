# DrDonutMenu 2.0 (Paper 1.21.11)

Build the jar (pick one):
- Computer: install JDK 21 + Maven, then run `mvn package`. Jar = target/DrDonutMenu.jar
- No install: upload this folder to a new GitHub repo. Open the Actions tab, wait for
  "Build plugin" to finish, download the DrDonutMenu artifact (contains the jar).

Then put the jar in your server's plugins folder and restart.
Commands: /menu /settings /home /sethome /delhome /homes /rtp /friend /follow /unfollow /tpa /tpaccept /tpdeny /pay
The buttons /ah /order /sell /stats /leaderboard must come from other plugins.
Edit menu labels/commands and defaults in plugins/DrDonutMenu/config.yml.
